<?php if(isset($this)) { if(!is_object($this)) { Header("Location: ../"); exit(); } } else { Header("Location: ../"); exit(); }
#	 ░▒▓███████▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓████████▓▒░▒▓████████▓▒░▒▓████████▓▒░▒▓█▓▒░░▒▓███████▓▒░▒▓█▓▒░░▒▓█▓▒░ 
#	░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░  ░▒▓█▓▒░   ░▒▓█▓▒░      ░▒▓█▓▒░      ░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ 
#	░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░  ░▒▓█▓▒░   ░▒▓█▓▒░      ░▒▓█▓▒░      ░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ 
#	 ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░  ░▒▓█▓▒░   ░▒▓██████▓▒░ ░▒▓██████▓▒░ ░▒▓█▓▒░░▒▓██████▓▒░░▒▓████████▓▒░ 
#		   ░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░  ░▒▓█▓▒░   ░▒▓█▓▒░      ░▒▓█▓▒░      ░▒▓█▓▒░      ░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ 
#		   ░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░  ░▒▓█▓▒░   ░▒▓█▓▒░      ░▒▓█▓▒░      ░▒▓█▓▒░      ░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ 
#	░▒▓███████▓▒░ ░▒▓██████▓▒░░▒▓█▓▒░  ░▒▓█▓▒░   ░▒▓████████▓▒░▒▓█▓▒░      ░▒▓█▓▒░▒▓███████▓▒░░▒▓█▓▒░░▒▓█▓▒░ 
	
#	Copyright (C) 2025 Jan Maurice Dahlmanns [Bugfish]

#	This program is free software: you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation, either version 3 of the License, or
#	(at your option) any later version.

#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.

#	You should have received a copy of the GNU General Public License
#	along with this program.  If not, see <https://www.gnu.org/licenses/>. ?>
##########################################################################################
## Store Versioning Translations
##########################################################################################
store_version_name=टेम्पलेट: Docker मॉड्यूल
store_version_description=हमारे एडमिनिस्ट्रेटर मॉड्यूल के लिए Docker सर्वर मैनेजर एक्सटेंशन के लिए एक Docker मॉड्यूल उदाहरण, विशेष रूप से डेवलपर्स के लिए। Docker मॉड्यूल के बारे में अधिक जानकारी Suitefish दस्तावेज़ और रिपॉजिटरी में संबंधित Readme.md फ़ाइलों में पाई जा सकती है।

##########################################################################################
## Substitution Explanation Translations
##########################################################################################
var_select_key=यह .env फ़ाइल में स्वतः उत्पन्न फ़ॉर्म के माध्यम से एकल चयन मान प्रतिस्थापन का उदाहरण है।
var_select_key_v1=यह पहला चयन मान है।
var_select_key_v2=यह दूसरा चयन मान है।
var_select_key_v3=यह तीसरा चयन मान है।
var_string_key=यह .env फ़ाइल में स्वतः उत्पन्न फ़ॉर्म के माध्यम से स्ट्रिंग मान प्रतिस्थापन का उदाहरण है।
var_numeric_key=यह .env फ़ाइल में स्वतः उत्पन्न फ़ॉर्म के माध्यम से संख्यात्मक मान प्रतिस्थापन का उदाहरण है।
var_port_key=यह .env फ़ाइल में स्वतः उत्पन्न फ़ॉर्म के माध्यम से पोर्ट मान प्रतिस्थापन का उदाहरण है।
var_checkbox_key=यह .env फ़ाइल में स्वतः उत्पन्न फ़ॉर्म के माध्यम से चेकबॉक्स मान प्रतिस्थापन का उदाहरण है।
