<?php if(isset($this)) { if(!is_object($this)) { exit(); } } else { exit(); }
#		@@@@@@@   @@@  @@@   @@@@@@@@  @@@@@@@@  @@@   @@@@@@   @@@  @@@  
#		@@@@@@@@  @@@  @@@  @@@@@@@@@  @@@@@@@@  @@@  @@@@@@@   @@@  @@@  
#		@@!  @@@  @@!  @@@  !@@        @@!       @@!  !@@       @@!  @@@  
#		!@   @!@  !@!  @!@  !@!        !@!       !@!  !@!       !@!  @!@  
#		@!@!@!@   @!@  !@!  !@! @!@!@  @!!!:!    !!@  !!@@!!    @!@!@!@!  
#		!!!@!!!!  !@!  !!!  !!! !!@!!  !!!!!:    !!!   !!@!!!   !!!@!!!!  
#		!!:  !!!  !!:  !!!  :!!   !!:  !!:       !!:       !:!  !!:  !!!  
#		:!:  !:!  :!:  !:!  :!:   !::  :!:       :!:      !:!   :!:  !:!  
#		 :: ::::  ::::: ::   ::: ::::   ::        ::  :::: ::   ::   :::  
#		:: : ::    : :  :    :: :: :    :        :    :: : :     :   : :  www.bugfish.eu
#		 _____   ____  _____ ______      ____  __ __  ____       ____   ____   ____    ___ 
#		|     | /    |/ ___/|      |    |    \|  |  ||    \     |    \ /    | /    |  /  _]
#		|   __||  o  (   \_ |      |    |  o  )  |  ||  o  )    |  o  )  o  ||   __| /  [_ 
#		|  |_  |     |\__  ||_|  |_|    |   _/|  _  ||   _/     |   _/|     ||  |  ||    _]
#		|   _] |  _  |/  \ |  |  |      |  |  |  |  ||  |       |  |  |  _  ||  |_ ||   [_ 
#		|  |   |  |  |\    |  |  |      |  |  |  |  ||  |       |  |  |  |  ||     ||     |
#		|__|   |__|__| \___|  |__|      |__|  |__|__||__|       |__|  |__|__||___,_||_____|
# This is a comment!
# Here you can enter translations for DE (German) like below!
# New Translation options should be applied to this sites config.php _HIVE_LANG_ARRAY_
# This files are public visible! You can use Database Mode if you want your translations hidden. ?>
##########################################################################################
## Backend Default Language Overrides for Login Scripts
##########################################################################################

# Strings - General
string_email=E-Mail
string_password=Password
string_login=Login
string_register=Register
string_close=Close

# Page - Actions
login_lostpass=Lost Password?
login_notregistered=Not Registered?
login_rememberme=Use Cookies?
login_recoveraccount=Recover Account
login_haveaccount=Already Have an Account?
login_password_confirm=Confirm Password
login_mc_change_mail=Change E-Mail
login_mc_backtohome=Back to Home
login_title_accactivation=Account Activation

# Login Events - General
hive_login_msg_l_wrong=Wrong Password/E-Mail combination.
hive_login_msg_csrf=Form expired, please try again.
hive_login_msg_empty=Please enter the required data!
hive_login_msg_ipban=Your IP is currently blocked; please try again later.
hive_login_msg_logout=You have been logged out!
hive_login_msg_nomatchpass=Password confirmation does not match the entered password.
login_doremember=Do you want to remember your password?

# Login Events - Login
hive_login_msg_l_ok=Login successful.
hive_login_msg_l_blocked=You cannot login because your account is blocked.
hive_login_msg_l_inactive=Your user account is not yet activated! Recover your password to activate your account or click the URL in the activation E-Mail you received!
hive_login_msg_l_blockedpwf=You have entered the wrong password too many times, and your account has been blocked!
hive_login_msg_l_disabled=Your user account has been disabled!
hive_login_mail_serror=Error while trying to send E-Mail. This is an internal error that needs to be investigated and should be reported to our website's staff.
hive_login_msg_register_ok=Please check your E-Mail inbox to activate your new account!
hive_login_msg_passfiltererror=The entered password does not meet the password rules!
hive_login_msg_mailexist=You are trying to register an account with an E-Mail that already exists!
login_password_rules=Password Rules
login_password_sign=Required Characters:
login_password_cap=Required Capital Letters:
login_password_small=Required Small Letters:
login_password_special=Required Special Characters:
login_password_numeric=Required Numeric Characters:

# Login Events - Mail Change
hive_login_msg_m_ok=You have successfully activated your new E-Mail!
hive_login_msg_m_er=Error while trying to activate the new E-Mail address; please try again.
hive_login_msg_m_exp=E-Mail activation code expired! Please retry to change your E-Mail!
hive_login_msg_m_res=The E-Mail you tried to activate is now used on another account, so it cannot be associated with your account!
hive_login_msg_m_block=Your account is blocked from E-Mail changes!
hive_login_msg_m_noadr=The request has failed. Please try again later.
login_mc_cmailtext=Your current E-Mail is:
hive_login_msg_rec_ok=Please check the new E-Mail inbox to activate the new E-Mail address.
hive_login_msg_rec_err=Error while trying to change E-Mail address.
hive_login_msg_rec_wait=You need to wait 120 minutes between E-Mail changes!
hive_login_msg_rec_exist=The E-Mail you are trying to change to is already used by another user account!
hive_login_msg_rec_block=Your account is blocked from E-Mail changes!
hive_login_msg_rec_disable=You cannot change the E-Mail of a disabled account!

# Login Mails
hive_login_mail_pre_change=Activate your new mail here:
hive_login_mail_title_change=Activate Your New E-Mail
hive_login_mail_title_register=Activate Your New Account
hive_login_mail_pre_register=Click the following link to activate your account:
hive_login_mail_title_rec=Recover Your Account
hive_login_mail_pre_rec=Click the following link to recover your account password:

# Login - Activation
hive_login_msg_a_ok=You have successfully activated your account! You can now login on our login pages on this website.
hive_login_msg_a_er=Error while trying to activate the user account. Please try to recover your account password or register a new account.
hive_login_msg_a_exp=The activation token is invalid. Please recover your account at the login page to activate your account!
hive_login_msg_a_block=Activation for your account has been disabled; please try again later!

# Login - Recover Request
hive_login_msg_rr_recnewunk=The provided E-Mail is not registered.
hive_login_msg_rr_recnope=Your account does not have permission to recover the password!
hive_login_msg_rr_recnopede=Your account has been deactivated and cannot make new requests!
hive_login_msg_rr_recwait=You need to wait 120 minutes before you start a new recovery request!
hive_login_msg_rr_recnok=Please check your inbox for a password reset E-Mail. This mail contains a link to recover your password.
hive_login_msg_recfr_ok=Please check your E-Mail inbox to get a password recovery link!

# Login - Recover Execute
hive_login_msg_pwtexpire=This Password Recovery Token has expired! Please retry to recover your account.
hive_login_msg_recexecerror=Error while trying to recover your password. Please try again to recover your account.
hive_login_msg_recexecok=You have successfully recovered your password and can now login with your new password.

##########################################################################################
## Module Related
##########################################################################################

head_template=Template
nav_sub_item=Subitem
nav_sub_login=Login
nav_sub_general=General
nav_sub_charts=Charts
nav_sub_forms=Forms
nav_sub_tables=Tables
nav_sub_submenue=Submenu
nav_sub_profile=Profile
nav_sub_logout=Logout
nav_sub_button=Create Account
top_bar_search=Search
404_title=Not Found!
404_text=The requested content was not found!
login_already=Already have an account? 
login_create=Create Account
login_agb=Accept Terms and Conditions
login_mail=Email
login_pass=Password
table_client=Client
table_value=Value
table_state=Status
table_date=Date
table_label=Label
table_listcount=X entries found!
table_withavatars=Table with Avatar Images
table_tables=Tables
table_withactions=Table with Actions
form_select=Selection
form_forms=Forms
form_elements=Elements
form_name=Input Field
form_radio=Radio Selection
form_business=Business
form_personal=Personal
form_multiselect=Multiple Selection
form_checkbox=Checkbox
form_textarea=Textarea
form_entersmto=Enter a value
form_buttons=Buttons
form_ir=Icon Right
form_br=Button Right
form_il=Icon Left
form_bl=Button Left
form_exec=Execute
form_icons=Icons
form_validation=Validations
form_invalid=Invalid Value
form_invalid_text=Error message on action
form_valid=Valid Value
form_valid_text=Message on valid action
form_helper=Help text
form_helper_text=This help text will be displayed
form_option=Selection Option
chart_charts=Charts
chart_pie=Pie Chart
chart_line=Line Chart
chart_bar=Bar Chart
chart_1=Charts provided by 
chart_2= . Note that default legends are disabled, and you should provide a description for your charts in HTML. See the source code for examples.
g_applytext=Use "w-full" for each button to create a block-level button.
g_goal=Project Goal
g_goal_t=At the heart of our platform is a revolutionary CMS aiming to push boundaries and bring fresh ideas and functionalities to the world of backend PHP development and web hosting. We are here to redefine the landscape and transform how professionals approach their work. Our commitment to innovation knows no bounds, and we invite you to join us in shaping the future of web development and hosting.<br ><br >At the core of our platform, you'll find a CMS that redefines the game, integrating groundbreaking ideas and functionalities into the world of backend PHP development and web hosting. Our approach is to catapult your professional journey to new heights. We are unwaveringly committed to innovation and invite you to be part of the evolution that changes the face of web development and hosting.
g_gggithub=Github URLs
g_info=Information
g_ok=OK
g_warning=Warning
g_error=Error
g_multiple=Multiple
g_alerts=Notifications
g_buttons=Buttons
g_icons=Icons
g_modal_title=Popups
g_cards=Boxes
g_bigsectioncard=Full-Width Box
g_responsivecards=Responsive Card
g_example=Example
g_cardswithtitle=Box with Title
g_evbclose=OK
g_evb=Event Boxes
g_modal=Popup Sweetalert
g_xjspopup=XJS Popup (Bugfish Framework)
g_xjspopup_close=Close
g_regularbutton=Regular Button
g_sizes=Normal Buttons
g_primary=Primary
g_credit=Acknowledgment
g_seegit=Github Repository
g_seedoc=Documentation
g_seegitm=Open URL
g_info_t=The "_windmilltheme" theme is an advanced and feature-rich option within our CMS ecosystem. It is tailored for users seeking a sophisticated yet user-friendly solution to quickly create responsive websites with dynamic navigation. Unlike its simpler counterpart, the "_example-minimal" theme, the "_windmilltheme" theme offers a wider range of features and design elements, allowing for a more sophisticated and visually appealing layout. It demonstrates how the CMS Site Module Folder is used to initialize its construction and deployment functionalities. All the information you need is in the README.md files in the website folders, explaining the purpose, and you can access a complete demonstration as a site module or through the link above.<br /><br />This theme is based on the Envato Windmill Theme. If you are using this theme and want to create a website, take a look at the code for this site module!<br /><br />With a focus on responsiveness, this theme ensures that your website looks and functions seamlessly on various devices. It includes a responsive navigation system that optimizes the user experience on both desktop and mobile platforms.<br /><br />Additionally, in the "_site" folder, you'll find the "_administrator" site module. This module features a comprehensive and dynamic administrative interface, allowing users to efficiently manage and customize their websites. It provides complex controls for all classes and advanced features of this CMS. It comes with a store that can be used.<br /><br />The focus of this module is to explain all the folders and configurations that can be set. So, if you need help, refer to this site module for inspirations on how to develop with this given CMS.<br /><br />Note: The "Bugfish PHP Framework" is fully integrated into this CMS. Detailed documentation is available on GitHub or can be found in the "docs" folder within the repositories. Dive into the comprehensive documentation to leverage the capabilities and features of the Bugfish Framework for enhanced website creation.<br /><br />To test functionalities and view the administration area, visit: "<a href="./developer.php">./developer.php</a>" - This file only works if "_HIVE_MOD_CHANGES_" is enabled through the administration interface or "ruleset.php" in the website's root directory. To log in as an administrator, visit: "<a href="./_core/_action/admin_switch.php">./_core/_action/admin_switch.php</a>".
g_credit_t=In our project documentation, we would like to express our heartfelt thanks to the Envato Windmill Dashboard Theme team. The seamless integration into the Fast PHP Page Framework has not only contributed to an appealing design but has also significantly simplified the development and deploying processes. <br /><br />The Github page of the Windmill project, which served as a template for this currently viewed site module, can be found here: <a href="https://github.com/estevanmaito/windmill-dashboard" rel="noopener" target="_blank">https://github.com/estevanmaito/windmill-dashboard</a>

g_theme_changes=Change Session Theme
g_theme_orange=Orange
g_theme_dyn=Dynamic
g_theme_purple=Purple
g_theme_green=Green
g_theme_color=Change Dynamic Theme Color
g_theme_color_change=Change Color
g_themela=Language changed successfully!
g_themeco=Color changed successfully!
g_themete=Theme changed successfully!
g_themetesu=Subtheme changed successfully!