<?php if(isset($this)) { if(!is_object($this)) { exit(); } } else { exit(); }
#		@@@@@@@   @@@  @@@   @@@@@@@@  @@@@@@@@  @@@   @@@@@@   @@@  @@@  
#		@@@@@@@@  @@@  @@@  @@@@@@@@@  @@@@@@@@  @@@  @@@@@@@   @@@  @@@  
#		@@!  @@@  @@!  @@@  !@@        @@!       @@!  !@@       @@!  @@@  
#		!@   @!@  !@!  @!@  !@!        !@!       !@!  !@!       !@!  @!@  
#		@!@!@!@   @!@  !@!  !@! @!@!@  @!!!:!    !!@  !!@@!!    @!@!@!@!  
#		!!!@!!!!  !@!  !!!  !!! !!@!!  !!!!!:    !!!   !!@!!!   !!!@!!!!  
#		!!:  !!!  !!:  !!!  :!!   !!:  !!:       !!:       !:!  !!:  !!!  
#		:!:  !:!  :!:  !:!  :!:   !::  :!:       :!:      !:!   :!:  !:!  
#		 :: ::::  ::::: ::   ::: ::::   ::        ::  :::: ::   ::   :::  
#		:: : ::    : :  :    :: :: :    :        :    :: : :     :   : :  www.bugfish.eu?>
##########################################################################################
## Backend Default Language Overrides for Login Scripts
##########################################################################################

# Strings - General
string_email=电子邮件
string_password=密码
string_login=登录
string_register=注册
string_close=关闭

# Page - Actions
login_lostpass=忘记密码？
login_notregistered=尚未注册？
login_rememberme=使用Cookies？
login_recoveraccount=找回账户
login_haveaccount=已有账户？
login_password_confirm=确认密码
login_mc_change_mail=更改电子邮件
login_mc_backtohome=返回首页
login_title_accactivation=账户激活

# Login Events - General
hive_login_msg_l_wrong=密码/电子邮件组合错误。
hive_login_msg_csrf=表单已过期，请重试。
hive_login_msg_empty=请输入必填信息！
hive_login_msg_ipban=您的IP当前被封禁，请稍后再试。
hive_login_msg_logout=您已退出登录！
hive_login_msg_nomatchpass=确认密码与输入的密码不匹配。
login_doremember=您想记住密码吗？

# Login Events - Login
hive_login_msg_l_ok=登录成功。
hive_login_msg_l_blocked=您的账户已被封禁，无法登录。
hive_login_msg_l_inactive=您的账户尚未激活！请通过找回密码激活您的账户，或点击您收到的激活电子邮件中的链接！
hive_login_msg_l_blockedpwf=您输入错误密码次数过多，账户已被封禁！
hive_login_msg_l_disabled=您的账户已被禁用！
hive_login_mail_serror=尝试发送电子邮件时出错。这是一个内部错误，需要报告给我们网站的工作人员处理。
hive_login_msg_register_ok=请检查您的电子邮件收件箱以激活您的新账户！
hive_login_msg_passfiltererror=输入的密码不符合密码规则！
hive_login_msg_mailexist=您尝试注册的电子邮件已存在！
login_password_rules=密码规则
login_password_sign=必需字符：
login_password_cap=必需大写字母：
login_password_small=必需小写字母：
login_password_special=必需特殊字符：
login_password_numeric=必需数字字符：

# Login Events - Mail Change
hive_login_msg_m_ok=您已成功激活新电子邮件！
hive_login_msg_m_er=激活新电子邮件地址时出错，请重试。
hive_login_msg_m_exp=电子邮件激活码已过期！请重新尝试更改电子邮件！
hive_login_msg_m_res=您尝试激活的电子邮件已被其他账户使用，无法与您的账户关联！
hive_login_msg_m_block=您的账户已被禁止更改电子邮件！
hive_login_msg_m_noadr=请求失败。请稍后再试。
login_mc_cmailtext=您的当前电子邮件是：
hive_login_msg_rec_ok=请检查新电子邮件收件箱以激活新电子邮件地址。
hive_login_msg_rec_err=尝试更改电子邮件地址时出错。
hive_login_msg_rec_wait=您需要等待120分钟才能再次更改电子邮件！
hive_login_msg_rec_exist=您尝试更改的电子邮件已被其他用户账户使用！
hive_login_msg_rec_block=您的账户已被禁止更改电子邮件！
hive_login_msg_rec_disable=您无法更改已被禁用账户的电子邮件！

# Login Mails
hive_login_mail_pre_change=在此激活您的新电子邮件：
hive_login_mail_title_change=激活您的新电子邮件
hive_login_mail_title_register=激活您的新账户
hive_login_mail_pre_register=点击以下链接以激活您的账户：
hive_login_mail_title_rec=找回您的账户
hive_login_mail_pre_rec=点击以下链接以找回您的账户密码：

# Login - Activation
hive_login_msg_a_ok=您已成功激活账户！您现在可以在本网站的登录页面登录。
hive_login_msg_a_er=激活账户时出错。请尝试找回您的账户密码或注册一个新账户。
hive_login_msg_a_exp=激活令牌无效。请在登录页面找回您的账户以激活您的账户！
hive_login_msg_a_block=您的账户激活已被禁用，请稍后再试！

# Login - Recover Request
hive_login_msg_rr_recnewunk=提供的电子邮件未注册。
hive_login_msg_rr_recnope=您的账户无权找回密码！
hive_login_msg_rr_recnopede=您的账户已被禁用，无法进行新请求！
hive_login_msg_rr_recwait=您需要等待120分钟才能发起新的找回请求！
hive_login_msg_rr_recnok=请检查您的收件箱，您会收到一封密码重置电子邮件。该邮件包含找回密码的链接。
hive_login_msg_recfr_ok=请检查您的电子邮件收件箱以获取密码找回链接！

# Login - Recover Execute
hive_login_msg_pwtexpire=此密码恢复令牌已过期！请重试找回您的账户。
hive_login_msg_recexecerror=尝试恢复密码时出错。请重试找回您的账户。
hive_login_msg_recexecok=您已成功恢复密码，现在可以使用新密码登录。

##########################################################################################
## Module Related
##########################################################################################

head_template=模板
nav_sub_item=子项目
nav_sub_login=登录
nav_sub_general=常规
nav_sub_charts=图表
nav_sub_forms=表单
nav_sub_tables=表格
nav_sub_submenue=子菜单
nav_sub_profile=个人资料
nav_sub_logout=登出
nav_sub_button=创建账户
top_bar_search=搜索
404_title=未找到！
404_text=未找到请求的内容！
login_already=已有账户？
login_create=创建账户
login_agb=接受条款和条件
login_mail=电子邮件
login_pass=密码
table_client=客户
table_value=数值
table_state=状态
table_date=日期
table_label=标签
table_listcount=找到X条记录！
table_withavatars=带头像的表格
table_tables=表格
table_withactions=带操作的表格
form_select=选择
form_forms=表单
form_elements=元素
form_name=输入字段
form_radio=单选项
form_business=商业
form_personal=个人
form_multiselect=多选
form_checkbox=复选框
form_textarea=文本区
form_entersmto=输入一个值
form_buttons=按钮
form_ir=右图标
form_br=右按钮
form_il=左图标
form_bl=左按钮
form_exec=执行
form_icons=图标
form_validation=验证
form_invalid=无效值
form_invalid_text=操作时的错误消息
form_valid=有效值
form_valid_text=操作成功的消息
form_helper=帮助文本
form_helper_text=此帮助文本将显示
form_option=选择选项
chart_charts=图表
chart_pie=饼图
chart_line=折线图
chart_bar=柱状图
chart_1=提供的图表来自
chart_2=。请注意默认图例已禁用，您应在HTML中为图表提供描述。参见源代码示例。
g_applytext=使用“w-full”创建块级按钮。
g_goal=项目目标
g_goal_t=我们平台的核心是一个革命性的CMS，旨在突破边界，为后端PHP开发和网页托管带来全新的理念和功能。我们在此重新定义格局，改变专业人员的工作方式。我们的创新承诺无限，邀请您加入我们，共同塑造网页开发和托管的未来。<br><br>在我们平台的核心，您会发现一个重新定义游戏的CMS，将突破性的创意和功能整合到后端PHP开发和网页托管中。我们以推动您的职业生涯达到新的高度为宗旨。我们始终坚持创新，邀请您成为变革的一部分，改变网页开发和托管的面貌。
g_gggithub=Github链接
g_info=信息
g_ok=确定
g_warning=警告
g_error=错误
g_multiple=多选
g_alerts=通知
g_buttons=按钮
g_icons=图标
g_modal_title=弹窗
g_cards=盒子
g_bigsectioncard=全宽盒子
g_responsivecards=响应式卡片
g_example=示例
g_cardswithtitle=带标题的盒子
g_evbclose=确定
g_evb=事件盒子
g_modal=弹窗Sweetalert
g_xjspopup=XJS弹窗（Bugfish框架）
g_xjspopup_close=关闭
g_regularbutton=普通按钮
g_sizes=正常按钮
g_primary=主要
g_credit=致谢
g_seegit=Github存储库
g_seedoc=文档
g_seegitm=打开URL
g_info_t="_windmilltheme" 主题是我们CMS生态系统中功能丰富的高级选项，专为需要快速创建带动态导航的响应式网站的用户设计。与较为简单的“_example-minimal”主题不同，"_windmilltheme"主题提供了更丰富的功能和设计元素，使布局更具美感。它展示了如何使用CMS站点模块文件夹初始化其构建和部署功能。所有信息均在网站文件夹的README.md文件中解释。<br><br>此主题基于Envato Windmill主题。如果您正在使用此主题并希望创建网站，请查看此站点模块的代码！<br><br>此主题专注于响应式设计，确保您的网站在各种设备上看起来和运行流畅。它包括一个响应式导航系统，优化了桌面和移动平台上的用户体验。<br><br>此外，在"_site"文件夹中，您可以找到"_administrator"站点模块。此模块提供了一个全面且动态的管理界面，使用户能够有效地管理和自定义其网站。它提供了CMS所有类和高级功能的复杂控制。<br><br>此模块的重点是解释所有可设置的文件夹和配置。如果您需要帮助，请参考此站点模块，以获取开发该CMS的灵感。<br><br>注意：“Bugfish PHP框架”已完全集成到该CMS中。详细文档可在Github或存储库的"docs"文件夹中找到。深入文档，充分利用Bugfish框架的功能来增强网站创建能力。<br><br>要测试功能并查看管理区域，请访问："<a href="./developer.php">./developer.php</a>" - 此文件仅在通过管理界面或网站根目录下的“ruleset.php”启用"_HIVE_MOD_CHANGES_"时才可用。要作为管理员登录，请访问："<a href="./_core/_action/admin_switch.php">./_core/_action/admin_switch.php</a>"。
g_credit_t=在我们的项目文档中，我们要向Envato Windmill Dashboard Theme团队表达诚挚的感谢。无缝集成到Fast PHP Page Framework中，不仅使设计更具吸引力，也极大简化了开发和部署过程。<br><br>当前查看的站点模块的Windmill项目Github页面可在此找到：<a href="https://github.com/estevanmaito/windmill-dashboard" rel="noopener" target="_blank">https://github.com/estevanmaito/windmill-dashboard</a>

g_theme_changes=更改会话主题
g_theme_orange=橙色
g_theme_dyn=动态
g_theme_purple=紫色
g_theme_green=绿色
g_theme_color=更改动态主题颜色
g_theme_color_change=更改颜色
g_themela=语言更改成功！
g_themeco=颜色更改成功！
g_themete=主题更改成功！
g_themetesu=子主题更改成功！
