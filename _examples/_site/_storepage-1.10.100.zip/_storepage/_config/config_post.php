<?php
	/* 	 _           ___ _     _   _____ _____ _____ 
		| |_ _ _ ___|  _|_|___| |_|     |     |   __|
		| . | | | . |  _| |_ -|   |   --| | | |__   |
		|___|___|_  |_| |_|___|_|_|_____|_|_|_|_____|
				|___|                                
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.
	*/	 if(!is_array($object)) { http_response_code(404); Header("Location: ../"); exit(); }
	#####################################################################################
	## Language Selection Settings
	#####################################################################################
		// Array for Language / Chooser in topbar Changer - Needs Fitting Configuration for Language Availability
		$lang_ar = array();
		$lang_ar[0]["current_img"] = _HIVE_URL_REL_."/_core/_vendor/country-flags-icons/png/"._HIVE_LANG_.".png";
		$lang_ar[0]["ident"] = "en";
		$lang_ar[0]["img"] = _HIVE_URL_REL_."/_core/_vendor/country-flags-icons/png/en.png";
		$lang_ar[0]["name"] = "English";

	#####################################################################################
	## Navigation Selection Settings
	#####################################################################################	
	
		// Main Menue (Used in Dashboard Themes)	
		$object["nav"] = array();
		$i = 0;
		$object["nav"][$i]["nav_title"] = "Home";	
		$object["nav"][$i]["nav_loc"] = hive__url(array("startpage", false, false));
		$object["nav"][$i]["nav_sub"] = false;
		$object["nav"][$i]["nav_act"] = "startpage";
		$object["nav"][$i]["nav_img"] = "bx bx-home";
		
		$i++;
		$object["nav"][$i]["nav_title"] = "Download";	
		$object["nav"][$i]["nav_loc"] = hive__url(array("download", false, false));
		$object["nav"][$i]["nav_sub"] = false;
		$object["nav"][$i]["nav_act"] = "download";
		$object["nav"][$i]["nav_img"] = "bx bx-cloud-download";
	
		$i++;
		$object["nav"][$i]["nav_title"] = "Store";
		$object["nav"][$i]["nav_sub"] = false;
		$object["nav"][$i]["nav_loc"] = hive__url(array("modules", false, false));
		$object["nav"][$i]["nav_act"] = "modules";	
		$object["nav"][$i]["nav_img"] = "bx bxs-dashboard";
	
		$i++;
		$object["nav"][$i]["nav_title"] = "Documentation";
		$object["nav"][$i]["nav_sub"] = false;
		$object["nav"][$i]["nav_loc"] = hive__url(array("documentation", false, false));
		$object["nav"][$i]["nav_act"] = "documentation";	
		$object["nav"][$i]["nav_img"] = "bx bx-book";	
	
		$i++;
		$object["nav"][$i]["nav_title"] = "How to get help?";
		$object["nav"][$i]["nav_sub"] = false;
		$object["nav"][$i]["nav_loc"] = hive__url(array("support", false, false));
		$object["nav"][$i]["nav_act"] = "support";	
		$object["nav"][$i]["nav_img"] = "bx bx-support";	
	
		$i++;
		$object["nav"][$i]["nav_sub"] = false;	
		$object["nav"][$i]["nav_img"] = "bx bx-code-curly"; # Box Icon Image Class
		$object["nav"][$i]["nav_title"] = "Visit our Github"; # Nav Name
		$object["nav"][$i]["nav_act"] = "github";	# Show as Active in Nav on Which First Location?
		$object["nav"][$i]["nav_loc"] = "https://github.com/bugfishtm/bugfish-cms"; # Location
		$object["nav"][$i]["nav_target"] = "_blank"; # Location
		
		$i++;
		$object["nav"][$i]["nav_sub"] = false;	
		$object["nav"][$i]["nav_img"] = "bx bx-paragraph"; # Box Icon Image Class
		$object["nav"][$i]["nav_title"] = "License Information"; # Nav Name
		$object["nav"][$i]["nav_act"] = "license";	# Show as Active in Nav on Which First Location?
		$object["nav"][$i]["nav_loc"] = hive__url(array("license", false, false)); # Location
		
		$i++;
		$object["nav"][$i]["nav_sub"] = false;	
		$object["nav"][$i]["nav_img"] = "bx bx-shield"; # Box Icon Image Class
		$object["nav"][$i]["nav_title"] = "Datenschutz/Privacy"; # Nav Name
		$object["nav"][$i]["nav_act"] = "privacy";	# Show as Active in Nav on Which First Location?
		$object["nav"][$i]["nav_loc"] = hive__url(array("privacy", false, false)); # Location
		
		$i++;
		$object["nav"][$i]["nav_title"] = "Impressum/Imprint"; # Nav Name
		$object["nav"][$i]["nav_img"] = "bx bxs-user-detail"; # Box Icon Image Class
		$object["nav"][$i]["nav_act"] = "impressum";	# Show as Active in Nav on Which First Location?
		$object["nav"][$i]["nav_sub"] = false;	
		$object["nav"][$i]["nav_loc"] = hive__url(array("impressum", false, false));

	#####################################################################################
	## Store Page Configuration
	#####################################################################################
		$object["var"]->setup("_HIVE_TITLE_",  "bugfishCMS", "Title for the Website");
		$object["var"]->setup("_STORE_IMPRESSUM_",  "<b>Impressum</b> Information", "Impressum for the Website");
		$object["var"]->setup("_STORE_PRIVACY_",  "<b>Privacy</b> Information", "Privacy Info for the Website");
		$object["var"]->setup("_STORE_FOOTER_",  "Footer <b>Text</b>", "Footer for the Website");
		$object["var"]->init_constant();