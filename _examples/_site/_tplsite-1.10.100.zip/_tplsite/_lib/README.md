# PHP Library Folder

The `_lib` folder is a critical component of BugfishCMS. It contains library files that provide essential functionalities and utilities required by the CMS during its operation.

Files in this folder that follow the naming pattern `lib.*.php` will be automatically included during the site startup, prior to the initialization phase. This ensures that necessary libraries are available for the CMS right from the beginning.

Happy Coding!  
Bugfish <3