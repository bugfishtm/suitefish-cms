<?php if(isset($this)) { if(!is_object($this)) { exit(); } } else { exit(); }
#		@@@@@@@   @@@  @@@   @@@@@@@@  @@@@@@@@  @@@   @@@@@@   @@@  @@@  
#		@@@@@@@@  @@@  @@@  @@@@@@@@@  @@@@@@@@  @@@  @@@@@@@   @@@  @@@  
#		@@!  @@@  @@!  @@@  !@@        @@!       @@!  !@@       @@!  @@@  
#		!@   @!@  !@!  @!@  !@!        !@!       !@!  !@!       !@!  @!@  
#		@!@!@!@   @!@  !@!  !@! @!@!@  @!!!:!    !!@  !!@@!!    @!@!@!@!  
#		!!!@!!!!  !@!  !!!  !!! !!@!!  !!!!!:    !!!   !!@!!!   !!!@!!!!  
#		!!:  !!!  !!:  !!!  :!!   !!:  !!:       !!:       !:!  !!:  !!!  
#		:!:  !:!  :!:  !:!  :!:   !::  :!:       :!:      !:!   :!:  !:!  
#		 :: ::::  ::::: ::   ::: ::::   ::        ::  :::: ::   ::   :::  
#		:: : ::    : :  :    :: :: :    :        :    :: : :     :   : :  www.bugfish.eu?>
##########################################################################################
## Administrator Translations
##########################################################################################

site_title=Page d’Administration Exemple
site_title_ext=Page d’Administration Exemple pour le Module _tplsite Extension
site_title_ext1=Ceci est juste un site de test pour le Module Exemple !
site_title_ext2=Vous n’avez pas les permissions nécessaires pour voir cette page !

example_permission=Voir la Page d’Administration
example_permission_descr=Permission pour Voir la Page du Module du Site Administratif.

nav_item=Module Exemple

site_settings=Aucun paramètre n’est disponible pour ce module ! Le fichier mod_setting inclus dans ce module est juste un exemple de création de contenu sur une page administrative.
