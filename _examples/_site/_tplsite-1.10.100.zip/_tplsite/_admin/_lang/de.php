<?php if(isset($this)) { if(!is_object($this)) { exit(); } } else { exit(); }
#		@@@@@@@   @@@  @@@   @@@@@@@@  @@@@@@@@  @@@   @@@@@@   @@@  @@@  
#		@@@@@@@@  @@@  @@@  @@@@@@@@@  @@@@@@@@  @@@  @@@@@@@   @@@  @@@  
#		@@!  @@@  @@!  @@@  !@@        @@!       @@!  !@@       @@!  @@@  
#		!@   @!@  !@!  @!@  !@!        !@!       !@!  !@!       !@!  @!@  
#		@!@!@!@   @!@  !@!  !@! @!@!@  @!!!:!    !!@  !!@@!!    @!@!@!@!  
#		!!!@!!!!  !@!  !!!  !!! !!@!!  !!!!!:    !!!   !!@!!!   !!!@!!!!  
#		!!:  !!!  !!:  !!!  :!!   !!:  !!:       !!:       !:!  !!:  !!!  
#		:!:  !:!  :!:  !:!  :!:   !::  :!:       :!:      !:!   :!:  !:!  
#		 :: ::::  ::::: ::   ::: ::::   ::        ::  :::: ::   ::   :::  
#		:: : ::    : :  :    :: :: :    :        :    :: : :     :   : :  www.bugfish.eu?>
##########################################################################################
## Administrator Translations
##########################################################################################

site_title=Beispiel-Administrationsseite
site_title_ext=Beispiel-Administrationsseite für das Modul _tplsite Erweiterung
site_title_ext1=Dies ist nur eine Testseite für das Beispielmodul!
site_title_ext2=Sie haben nicht die erforderliche Berechtigung, um diese Seite anzuzeigen!

example_permission=Administrationsseite anzeigen
example_permission_descr=Berechtigung zum Anzeigen der Seite des Verwaltungsmoduls.

nav_item=Beispielmodul

site_settings=Für dieses Modul sind keine Einstellungen verfügbar! Die in diesem Modul enthaltene Datei mod_setting ist nur ein Beispiel dafür, wie Inhalte auf einer Administrationsseite angezeigt werden können.
