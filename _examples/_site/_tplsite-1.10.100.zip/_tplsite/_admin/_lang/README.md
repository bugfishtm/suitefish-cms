# Administrator Translations

This folder is to include translations for interfaces shown in the external _administrator module.

Happy Coding!  
Bugfish <3 