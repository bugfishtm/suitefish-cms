<?php if(isset($this)) { if(!is_object($this)) { exit(); } } else { exit(); }
#		@@@@@@@   @@@  @@@   @@@@@@@@  @@@@@@@@  @@@   @@@@@@   @@@  @@@  
#		@@@@@@@@  @@@  @@@  @@@@@@@@@  @@@@@@@@  @@@  @@@@@@@   @@@  @@@  
#		@@!  @@@  @@!  @@@  !@@        @@!       @@!  !@@       @@!  @@@  
#		!@   @!@  !@!  @!@  !@!        !@!       !@!  !@!       !@!  @!@  
#		@!@!@!@   @!@  !@!  !@! @!@!@  @!!!:!    !!@  !!@@!!    @!@!@!@!  
#		!!!@!!!!  !@!  !!!  !!! !!@!!  !!!!!:    !!!   !!@!!!   !!!@!!!!  
#		!!:  !!!  !!:  !!!  :!!   !!:  !!:       !!:       !:!  !!:  !!!  
#		:!:  !:!  :!:  !:!  :!:   !::  :!:       :!:      !:!   :!:  !:!  
#		 :: ::::  ::::: ::   ::: ::::   ::        ::  :::: ::   ::   :::  
#		:: : ::    : :  :    :: :: :    :        :    :: : :     :   : :  www.bugfish.eu?>
##########################################################################################
## Administrator Translations
##########################################################################################

site_title=Página de Administración de Ejemplo
site_title_ext=Página de Administración de Ejemplo para el Módulo _tplsite Extensión
site_title_ext1=¡Este es solo un sitio de prueba para el Módulo de Ejemplo!
site_title_ext2=¡No tienes los permisos necesarios para ver esta página!

example_permission=Ver Página de Administración
example_permission_descr=Permiso para Ver la Página del Módulo del Sitio Administrativo.

nav_item=Módulo de Ejemplo

site_settings=¡No hay configuraciones disponibles para este módulo! El archivo mod_setting incluido en este módulo es solo un ejemplo de cómo generar contenido en una página administrativa.
