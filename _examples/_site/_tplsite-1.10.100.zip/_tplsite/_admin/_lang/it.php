<?php if(isset($this)) { if(!is_object($this)) { exit(); } } else { exit(); }
#		@@@@@@@   @@@  @@@   @@@@@@@@  @@@@@@@@  @@@   @@@@@@   @@@  @@@  
#		@@@@@@@@  @@@  @@@  @@@@@@@@@  @@@@@@@@  @@@  @@@@@@@   @@@  @@@  
#		@@!  @@@  @@!  @@@  !@@        @@!       @@!  !@@       @@!  @@@  
#		!@   @!@  !@!  @!@  !@!        !@!       !@!  !@!       !@!  @!@  
#		@!@!@!@   @!@  !@!  !@! @!@!@  @!!!:!    !!@  !!@@!!    @!@!@!@!  
#		!!!@!!!!  !@!  !!!  !!! !!@!!  !!!!!:    !!!   !!@!!!   !!!@!!!!  
#		!!:  !!!  !!:  !!!  :!!   !!:  !!:       !!:       !:!  !!:  !!!  
#		:!:  !:!  :!:  !:!  :!:   !::  :!:       :!:      !:!   :!:  !:!  
#		 :: ::::  ::::: ::   ::: ::::   ::        ::  :::: ::   ::   :::  
#		:: : ::    : :  :    :: :: :    :        :    :: : :     :   : :  www.bugfish.eu?>
##########################################################################################
## Administrator Translations
##########################################################################################

site_title=Pagina Amministrativa di Esempio
site_title_ext=Pagina Amministrativa di Esempio per il Modulo _tplsite Estensione
site_title_ext1=Questo è solo un sito di prova per il Modulo Esempio!
site_title_ext2=Non hai i permessi necessari per visualizzare questa pagina!

example_permission=Visualizza Pagina Amministrativa
example_permission_descr=Permesso per Visualizzare la Pagina del Modulo del Sito Amministrativo.

nav_item=Modulo Esempio

site_settings=Non sono disponibili impostazioni per questo modulo! Il file mod_setting incluso in questo modulo è solo un esempio di come generare contenuto su una pagina amministrativa.
