<?php
	/* 
		 _               __ _    _    ___ __  __ ___ 
		| |__ _  _ __ _ / _(_)__| |_ / __|  \/  / __|
		| '_ \ || / _` |  _| (_-< ' \ (__| |\/| \__ \
		|_.__/\_,_\__, |_| |_/__/_||_\___|_|  |_|___/
				  |___/                              

		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
	*/ if(!is_array($object)) { @http_response_code(404); Header("Location: ../"); exit(); }
	
	// Add a Navigation Element in Administrative or Public Area!
	if(hive__access($object, array("__smadmin_".$object["cmod"]."__example_permission"), false)) { 
		array_push($object["nav"], array("nav_title" => $object["inject"]["lang"]->translate("nav_item"), 
										 "nav_img" => "web", 
										 "nav_sub" => false, 
										 "nav_act" => "smadmin_".$object["cmod"], 
										 "nav_loc" => hive__url(array("smadmin_".$object["cmod"], false, false, false))));	
	}