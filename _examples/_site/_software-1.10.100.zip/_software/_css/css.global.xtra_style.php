	/* 	 _           ___ _     _   _____ _____ _____ 
		| |_ _ _ ___|  _|_|___| |_|     |     |   __|
		| . | | | . |  _| |_ -|   |   --| | | |__   |
		|___|___|_  |_| |_|___|_|_|_____|_|_|_|_____|
				|___|                                
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.
	*/	

	.background-success {
		background: lime;
		color: black;}

	.force-white-focus:hover  {
		background: white !important;
		color: black !important;}
		
	.bg-primary-bugfish {
		background: black;
	}
	.bg-primary-bugfish:hover {
		background: white;
		color: black;
	}
	.shadow-primary-bugfish:focus {
		border-color: red;
	}
	.transition-colors {
		border-color: #242424;
	}
	button {
		color: #cccccc;
	}
	.text-bugfish-primary {
		color: #cccccc;
	}
	.button {
		color: grey;
	}
	.button svg {
		color: grey;
	}
	a {
		color: <?php echo _HIVE_COLOR_; ?>;
	}
	.text-bugfish-primary-600 {
		color: <?php echo _HIVE_COLOR_; ?>;
	}
	.background-danger {
		background: red;
	}
	.background-warning {
		background: yellow;
		color: black;
	}
	.background-info {
		background: blue;
	}
	.background-primary {
		background: <?php echo _HIVE_COLOR_; ?>;
		color: white;
	}
	.bugfish-primary-color {
		color: <?php echo _HIVE_COLOR_; ?> !important;
	}

	@media (min-width: 768px) {
		.fix-turnout-navigation {
			display: none;
		}
	}

	footer#web_footer {
		position: fixed;
		bottom: 0px;
		z-index: 28;
		width: 100%;
		padding: 15px;
		padding-top: 5px;
		padding-bottom: 5px;
		text-align: center;
		font-size: 12px;
	}

	main {
		padding-bottom: 50px;
	}

	.navi-sub-item-inactive {
		color: <?php echo _HIVE_COLOR_; ?> !important;
	}


	.navi-sub-item-inactive {
		color: #999999 !important;
	}
	
	.sidebarMenu, .simplebar-offset {
		background: #242424 !important;
	}
	
	html, body {
		background: #121212;
	}
	
	.content {
		background: #121212;
	}
	.content h1 {
		color: white;
	}
	
	.card {
		background: #242424;
		border: none !important;
		border-radius: 0px !important;
		box-shadow: none !important;
		color: white;
	}
	.card h1, .card h2, .card h3 {
		color: white !important;
	}
	
	.h2, .h3 {
		color: white !important;
	}
	.card-body {
		background: #242424;
		border: none !important;
	}
	
	
	.card a {
		color: #FFFF00;
	}
	
	.btn-primary {
		background: #FFFF00;
		color: black !important;
	}
	.btn-primary:focus {
		background: #FFFFFF !important;
		color: black !important;
	}
	
	.navbar-theme-primary  {
		background: #242424 !important;
	}
	
	.nav-item.active .nav-link {
		background: #121212 !important;
	}
	.nav-item .nav-link:hover {
		background: #121212 !important;
	}
	
	.card {
		border-radius: 0px;
	}
	
	.store_hoverhide:hover {
		background: white !important;
	}