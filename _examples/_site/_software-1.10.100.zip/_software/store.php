<?php
	/* 	 _           ___ _     _   _____ _____ _____ 
		| |_ _ _ ___|  _|_|___| |_|     |     |   __|
		| . | | | . |  _| |_ -|   |   --| | | |__   |
		|___|___|_  |_| |_|___|_|_|_____|_|_|_|_____|
				|___|                                
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.
	*/	
	if(!is_array($object)) { @http_response_code(404); Header("Location: ../"); exit(); } ?>	
            <div class="py-4 pt-2 pb-2">
                <div class="d-flex justify-content-between w-100 flex-wrap">
                    <div class="mb-3 mb-lg-0">
                        <h1 class="h4">Software Store</h1>
                    </div>
                </div>
            </div>            

            <div class="row mb-0">
                <div class="col-12 col-xl-4">
					<div class="card border-0 shadow mb-4">
						<div class="card-body ">
							<span class="h2 fs-5 fw-bold mb-1">Explore our software!</span><br />
							<p>Here you can find our released windows software! You can get more information by selecting a software out of the list below or to the right (depending on your screen size). If you have any issues, feel free to contact us by using the "<b><a href="./?l1=support">How to get help</a></b>" Section. Developer and user documentation can be found in our "<b><a href="./?l1=documentation">Documentation</a></b>" section!</p>
							<div class="d-block">
								<div class="d-flex align-items-center me-5">
									<div class="icon-shape icon-sm bg-light rounded me-3">
										<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#ffffff"><path d="M120-80v-60h100v-30h-60v-60h60v-30H120v-60h120q17 0 28.5 11.5T280-280v40q0 17-11.5 28.5T240-200q17 0 28.5 11.5T280-160v40q0 17-11.5 28.5T240-80H120Zm0-280v-110q0-17 11.5-28.5T160-510h60v-30H120v-60h120q17 0 28.5 11.5T280-560v70q0 17-11.5 28.5T240-450h-60v30h100v60H120Zm60-280v-180h-60v-60h120v240h-60Zm180 440v-80h480v80H360Zm0-240v-80h480v80H360Zm0-240v-80h480v80H360Z"/></svg>
									</div>
									<div class="d-block">
										<label class="mb-0">Available Software</label><br />
										<span class="h4 mb-0 text-white"><?php if($mods) { echo count($mods); } else { echo "Not available"; } ?></span>
									</div>
								</div>
							</div>
							<p class="mt-3 mb-1">We will very appreciate support for this project on "<b><a href="https://www.patreon.com/Bugfish" rel="noopener" target="_blank">Patreon</a></b>"!</p>
						</div>
					</div>
					<div class="card border-0 shadow mb-4">
						<div class="card-body ">
							<span class="h2 fs-5 fw-bold mb-1">All for free!</span><br />
							<p>This store is dedicated to non-paid software. This means you can use all the items here totally for free!</p>
							<div class="d-block">
								<div class="d-flex align-items-center me-5">
									<div class="icon-shape icon-sm bg-light rounded me-3">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: rgba(255, 255, 255, 1);transform: ;msFilter:;"><path d="M14 9h8v6h-8z"></path><path d="M20 3H5C3.346 3 2 4.346 2 6v12c0 1.654 1.346 3 3 3h15c1.103 0 2-.897 2-2v-2h-8c-1.103 0-2-.897-2-2V9c0-1.103.897-2 2-2h8V5c0-1.103-.897-2-2-2z"></path></svg>
									</div>
									<div class="d-block">
										<label class="mb-0">Price for all items:</label><br />
										<span class="h4 mb-0 text-white">0.00$</span>
									</div>
								</div>
							</div>
						</div>
					</div>
                </div>		
                <div class="col-12 col-xl-8">	
					<div class="col-12 mb-4">
					<?php
						// Folder containing the files
						$last = false;
						if(is_array($mods)) {
							$mods = array_reverse($mods);
							foreach($mods as $key => $value) {
								if($value["mod_rname"] == $last) { 
									continue;
								}
								$last = $value["mod_rname"];
					?>			
						<div class="col-12 mb-4">
							<div class="card border-0 shadow">
								<div class="card-header store_hoverhide" onclick="showhide_store($(this));">
									<div class="row align-items-center">
										<div class="col" style="font-size: 13px;"> 
											<h2 class="fs-6 fw-bold mb-0"><?php echo htmlspecialchars($value["mod_name"] ?? ''); ?></h2>
											<small class="text-info">Identification ID: <?php echo $value["mod_rname"]; ?></small><br />
											<?php if($value["mod_type"] == 2) { echo '<span class="badge bg-primary">Script</span>'; } elseif($value["mod_type"] == 3) { echo '<span class="badge bg-secondary">Extension</span>'; } elseif($value["mod_type"] == 4) { echo '<span class="badge bg-info">Image</span>'; } elseif($value["mod_type"] == 1) { echo '<span class="badge bg-danger">Windows</span>'; } ?>
											<?php echo htmlspecialchars($value["mod_short"] ?? ''); ?>
										</div>
									</div>
								</div>
								<div class="card-body store_autohide">
									<?php if($value["mod_type"] == 3) { ?>  
										<div class="alert alert-warning"><small>This is an extension! You need the website module with the Identification ID: "<?php echo $value["mod_parent_rname"]; ?>" to deploy and use this extension.</small></div>
									<?php } ?>
									<?php if(file_exists("./_store/_hub/_download/_image/".$value["mod_rname"]."-".$value["mod_version"].".jpg")) { ?><div style="float: left;padding: 15px; max-width: 100%; width: 200px;padding-top: 0px; padding-left: 0px;">
										<img src="./_store/_hub/_download/_image/<?php echo $value["mod_rname"]."-".$value["mod_version"]; ?>.jpg">
									</div> <?php } ?>
									<div class="fs-6" style="font-size: 13px !important;">
										<?php echo htmlspecialchars($value["mod_description"] ?? '');?>
									</div><br clear="both">
									<div class="">
										<table style="font-size: 13px; width: 100%;">
										<tr><td><b>Languages</b> </td><td> 
											<?php
												if($newlang = unserialize($value["mod_lang"])) {
													foreach($newlang AS $keyy => $valuey) {
														echo "<img style='max-width: 30px;' src='./_core/_vendor/country-flags-icons/png/".$valuey.".png'> ";
													}
												} else {
													echo "Unkown";
												}
											?>
										
										</td></tr>
										<tr><td><b>License</b> </td><td><?php echo htmlspecialchars($value["mod_license"] ?? '');?></td></tr>
										<tr><td><b>Autor</b> </td><td> <?php echo htmlspecialchars($value["mod_autor"] ?? ''); ?> 
										[<?php echo htmlspecialchars($value["mod_mail"] ?? ''); ?>]</td></tr>
										<tr><td><b>Website</b> </td><td> <a target="_blank" href="<?php echo htmlspecialchars($value["mod_website"] ?? ''); ?>" rel="noopener"><?php echo htmlspecialchars($value["mod_website"] ?? ''); ?></a></td></tr>
										</table>
										<table style="font-size: 13px; width: 100%;">
											<?php
												foreach($mods as $keyx => $valuex) {
													if($value["mod_rname"] != $valuex["mod_rname"] /*OR ($valuex["mod_version"] == $value["mod_version"] AND $valuex["mod_build"] == $value["mod_build"]) */) { continue; }
													?>
														<tr style="width: 100%;">
															<td style="min-width: 100px; max-width: 100%; min-width: 100%;"><hr> <font size="+1"><b>Version</b>: <?php echo $valuex["mod_version"]; ?></font><br /><br />
															<?php if(file_exists($object["path"]."/_store/_hub/_download/_changelog/".$valuex["mod_rname"]."-".$valuex["mod_version"].".html")) { require_once($object["path"]."/_store/_hub/_download/_changelog/".$valuex["mod_rname"]."-".$valuex["mod_version"].".html"); } else { echo "Not available"; } ?><br /><br />
															<a class="btn btn-primary" href="./_store/_hub/_download/_release/<?php echo $valuex["mod_rname"]."-".$valuex["mod_version"].".zip"; ?>">Download</a>
															</td>
														</tr>
													<?php
												}
											?>
										</table>
									</div>
								</div>
							</div>
						</div>
						<?php
								}
							} else { 
						?>			
							<div class="col-12 mb-4">
								<div class="card border-0 shadow">
									<div class="card-header">
										<div class="row align-items-center">
											<div class="col">
												<h2 class="fs-5 fw-bold mb-0">Currently no items available!</h2>
												There are currently no store items available, please come back later!
											</div>
										</div>
									</div>
									<div class="table-responsive">

									</div>
								</div>
							</div>
						<?php
							}
						?>		
						<style>
							.store_hoverhide {
								border-radius: 0px !important;
							}
							.store_hoverhide:hover {
								background: #323232 !important;
								color: white !important;
								cursor: pointer;
							}
							
							.store_hoverhide:hover h2 {
								background: #323232 !important;
								color: white !important;
							}
							.store_act {
								border-radius: 0px !important;
								color: black !important;
								cursor: pointer;
								background: #FFFF00 !important;
							}
							.store_act h2 {
								color: black !important;
								background: #FFFF00 !important;
							}
						</style>
						<script>
							$(".store_autohide").hide();
							function showhide_store(thisvar) {
								thisvar.addClass('store_clicked');
								thisvar.next().toggle();
								$(".store_hoverhide").each(function() {
									if($(this).hasClass('store_clicked')) { return true; }
									
									$(this).next().hide();
									$(this).css('background-color', '#242424');
									$(this).css('color', '#FFFFFF');
									$(this).removeClass('store_act');
								});				
								thisvar.removeClass('store_clicked');				
								
								if(thisvar.hasClass('store_act')) { 
									thisvar.css('background-color', '#242424');
									thisvar.css('color', '#FFFFFF');
									thisvar.removeClass('store_act');
								} else {
									thisvar.css('background-color', '#242424');
									thisvar.addClass('color', 'white !important');
									thisvar.addClass('store_act');
								}
							}
						</script>
					</div>
                </div>
            </div>	