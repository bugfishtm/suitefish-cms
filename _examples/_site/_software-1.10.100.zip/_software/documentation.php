<?php
	/* 	 _           ___ _     _   _____ _____ _____ 
		| |_ _ _ ___|  _|_|___| |_|     |     |   __|
		| . | | | . |  _| |_ -|   |   --| | | |__   |
		|___|___|_  |_| |_|___|_|_|_____|_|_|_|_____|
				|___|                                
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.
	*/	
	if(!is_array($object)) { @http_response_code(404); Header("Location: ../"); exit(); }
?>	
             <div class="py-4 pt-2 pb-2">
                <div class="d-flex justify-content-between w-100 flex-wrap">
                    <div class="mb-3 mb-lg-0">
                        <h1 class="h4">Documentation</h1>
                    </div>
                </div>
            </div>         
		
			<!--<div class="col-12 mb-2 pb-0">
				<div class="card border-light shadow-sm components-section pb-0">
					<div class="card-body pb-0">
						<h2 class="h5">bugfishHUB</h2>
						<p>
							You can access the bugfishHUB Documentation with the Mirror-Buttons below!<br />
							<a href="https://bugfishtm.github.io/bugfish-hub" class="btn btn-primary" rel="nofollow noopener noreferrer" target="_blank">Mirror 1</a>
							<a href="https://bugfish-github.de/bugfish-hub" class="btn btn-primary" rel="nofollow noopener noreferrer" target="_blank">Mirror 2</a>
						</p>
					</div>
				</div>
			</div>
			<div class="col-12 mb-2 pb-0">
				<div class="card border-light shadow-sm components-section pb-0">
					<div class="card-body pb-0">
						<h2 class="h5">bugfishAPP</h2>
						<p>
							You can access the bugfishAPP Documentation with the Mirror-Buttons below!<br />
							<a href="https://bugfishtm.github.io/bugfish-app" class="btn btn-primary" rel="nofollow noopener noreferrer" target="_blank">Mirror 1</a>
							<a href="https://bugfish-github.de/bugfish-app" class="btn btn-primary" rel="nofollow noopener noreferrer" target="_blank">Mirror 2</a>
						
						
						</p>
					</div>
				</div>
			</div>
			<div class="col-12 mb-4 pb-0">
				<div class="card border-light shadow-sm components-section pb-0">
					<div class="card-body pb-0">
						<h2 class="h5">bugfishCMS</h2>
						<p>
							The software features on this page "bugfishHUB" and "bugfishAPP" are to be used with an "bugfishCMS" instance. Get Informations about bugfishCMS at the button below, which will transfer you to the official bugfishCMS Website. Software out of the bugfishHUB Store can mostly also be used without bugfishCMS/bugfishHUB as this is mostly standalone windows software.<br />
							<a href="https://store.bugfish.eu" class="btn btn-primary" rel="nofollow noopener noreferrer" target="_blank">bugfishCMS</a>
						</p>
					</div>
				</div>
			</div>-->
			<div class="col-12 mb-2 pb-2">
				<div class="card border-light shadow-sm components-section pb-0 mb-0">
					<div class="card-body pb-0">
						<h2 class="h5">What is this page about?</h2>
						<p>
							In the near future, this page will serve as a dedicated download hub for both an Android app and Windows software designed to seamlessly integrate with BugfishCMS. Users will be able to easily access and download the necessary tools to enhance their experience and functionality with BugfishCMS on their preferred platforms. Stay tuned for updates as we prepare to launch these exciting new resources.
						</p>
						<p>
							In addition to serving as a download hub, this page will also feature a store where users can explore and purchase a range of software solutions.
						</p>
					</div>
				</div>
			</div>		
			<div class="col-12 mb-2 pb-2">
				
				<div class="card border-light shadow-sm components-section pb-0 mb-0">
					<div class="card-body pb-0 mb-0">
						<h2 class="h5">Software Documentation</h2>
						<p>
							If you need help using software of the store see the related Github or Documentation URLs for help.
						</p>
					</div>
				</div>
			</div>			