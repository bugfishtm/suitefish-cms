<?php
	/* 
		 _               __ _    _    ___ __  __ ___ 
		| |__ _  _ __ _ / _(_)__| |_ / __|  \/  / __|
		| '_ \ || / _` |  _| (_-< ' \ (__| |\/| \__ \
		|_.__/\_,_\__, |_| |_/__/_||_\___|_|  |_|___/
				  |___/                              

		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
		
		File Description:
			Example of a Public Page Script.
			Can be viewed directly by hardlinking or connected via iframe!
			No Variables are pre-loaded here. you need to include Libraries and other 
			functionalities on your own if necessary.
			You can include settings.php to get the object array with all functionalities and
			the current site initiated variables
	*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BPM Determination</title>
    <style>
        body, html {
            height: 100%;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        .centered-content {
            text-align: center;
        }
    </style>
	<script>
		let bpm = 0;
		let millisecound = 0;
		let timer;
		let isStarted = 0;
	  
		timer = setInterval(() => {
		  if(isStarted == 1) { 
			  millisecound += 20;
			  if  (Number.isInteger(millisecound/1000)) {document.getElementById("bpmtexttime").innerHTML = (millisecound/1000) + ".0";} 
			  else {document.getElementById("bpmtexttime").innerHTML = millisecound/1000;}
		  }
		}, 20);		

		function start() {
			document.getElementById("resetbutton").disabled = false;
			if(isStarted == 0 && millisecound == 0) { isStarted = 1; } else { isStarted = 0; }
			
			bpm = 60000/millisecound;
			document.getElementById("bpmtext").innerHTML = Math.round(bpm, 2);
			
			millisecound = 0;
			isStarted = 1;
		}	
		
		function init() {
			document.getElementById("resetbutton").disabled = true;
			document.getElementById("startbutton").disabled = false;
			isStarted = 0;
			millisecound = 0;
			bpm = 0;
		} setTimeout(function(){ init(); }, 1000);
		
		function reset() {
			document.getElementById("resetbutton").disabled = true;
			document.getElementById("startbutton").disabled = false;
			isStarted = 0;
			millisecound = 0;
			bpm = 0;
		}
	</script>
</head>
<body>
    <div class="centered-content">
			<font size="+4" id="bpmtext">CLICK</font></font><br/>
			<font id="bpmtexttime">TO START</font></font><br/>
			<button id="startbutton" onclick="start()" disabled>Click</button> 
			<button id="resetbutton" onclick="reset()" disabled>Reset</button>
    </div>
</body>
</html>