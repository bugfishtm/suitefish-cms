<?php
	/* 
		 _               __ _    _    ___ __  __ ___ 
		| |__ _  _ __ _ / _(_)__| |_ / __|  \/  / __|
		| '_ \ || / _` |  _| (_-< ' \ (__| |\/| \__ \
		|_.__/\_,_\__, |_| |_/__/_||_\___|_|  |_|___/
				  |___/                              

		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
		
		File Description:
			Restricted Example Script PHP Script.
			Can be included via PHP Require_once and you can write code here which will be executed.
			You will have access to all site modules variables.
	*/ if(!is_array($object)) { @http_response_code(404); echo "No hardlinking allowed!"; exit(); }
?>
	<script>
		let srcbpmbutton_bpm = 0;
		let srcbpmbutton_millisecound = 0;
		let srcbpmbutton_timer;
		let srcbpmbutton_isStarted = 0;
	  
		timer = setInterval(() => {
		  if(srcbpmbutton_isStarted == 1) { 
			  srcbpmbutton_millisecound += 20;
			  if  (Number.isInteger(srcbpmbutton_millisecound/1000)) {document.getElementById("srcbpmbutton_bpmtexttime").innerHTML = (srcbpmbutton_millisecound/1000) + ".0";} 
			  else {document.getElementById("srcbpmbutton_bpmtexttime").innerHTML = srcbpmbutton_millisecound/1000;}
		  }
		}, 20);		

		function srcbpmbutton_start() {
			document.getElementById("srcbpmbutton_resetbutton").disabled = false;
			if(srcbpmbutton_isStarted == 0 && srcbpmbutton_millisecound == 0) { srcbpmbutton_isStarted = 1; } else { srcbpmbutton_isStarted = 0; }
			
			srcbpmbutton_bpm = 60000/srcbpmbutton_millisecound;
			document.getElementById("srcbpmbutton_bpmtext").innerHTML = Math.round(srcbpmbutton_bpm, 2);
			
			srcbpmbutton_millisecound = 0;
			srcbpmbutton_isStarted = 1;
		}	
		
		function srcbpmbutton_init() {
			document.getElementById("srcbpmbutton_resetbutton").disabled = true;
			document.getElementById("srcbpmbutton_startbutton").disabled = false;
			srcbpmbutton_isStarted = 0;
			srcbpmbutton_millisecound = 0;
			srcbpmbutton_bpm = 0;
		} setTimeout(function(){ srcbpmbutton_init(); }, 1000);
		
		function srcbpmbutton_reset() {
			document.getElementById("srcbpmbutton_resetbutton").disabled = true;
			document.getElementById("srcbpmbutton_startbutton").disabled = false;
			srcbpmbutton_isStarted = 0;
			srcbpmbutton_millisecound = 0;
			srcbpmbutton_bpm = 0;
		}
	</script>
    <div style="text-align: center;">
			<font size="+4" id="srcbpmbutton_bpmtext">CLICK</font></font><br/>
			<font id="srcbpmbutton_bpmtexttime">TO START</font></font><br/>
			<button id="srcbpmbutton_startbutton" onclick="srcbpmbutton_start()" disabled>Click</button> 
			<button id="srcbpmbutton_resetbutton" onclick="srcbpmbutton_reset()" disabled>Reset</button>
    </div>