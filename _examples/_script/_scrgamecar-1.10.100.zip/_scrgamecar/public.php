<?php
	/* 
		 _               __ _    _    ___ __  __ ___ 
		| |__ _  _ __ _ / _(_)__| |_ / __|  \/  / __|
		| '_ \ || / _` |  _| (_-< ' \ (__| |\/| \__ \
		|_.__/\_,_\__, |_| |_/__/_||_\___|_|  |_|___/
				  |___/                              

		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
		
		File Description:
			Example of a Public Page Script.
			Can be viewed directly by hardlinking or connected via iframe!
			No Variables are pre-loaded here. you need to include Libraries and other 
			functionalities on your own if necessary.
			You can include settings.php to get the object array with all functionalities and
			the current site initiated variables
	*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Car Game</title>
    <style>
        body, html {
            height: 100%;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        .centered-content {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="centered-content" style="max-width: 400px;">
		Do not hit the red cars! You can control your blue car with the arrow keys left/right.<br />
		The game will get faster and your score higher, if you fail you need to reload the page to retry!
		<canvas id="srcgamecar_gameCanvas" width="600" height="400"></canvas>
	</div>
	<script>
	  const srcgamecar_canvas = document.getElementById("srcgamecar_gameCanvas");
	  const srcgamecar_ctx = srcgamecar_canvas.getContext("2d");

	  // Player car
	  const srcgamecar_player = {
		x: srcgamecar_canvas.width / 2 - 25,
		y: srcgamecar_canvas.height - 75,
		width: 50,
		height: 75,
		speed: 5
	  };

	  // Police cars
	  const srcgamecar_policeCars = [];

	  // Add a new police car every 2 seconds
	  setInterval(() => {
		const srcgamecar_newPoliceCar = {
		  x: Math.floor(Math.random() * (srcgamecar_canvas.width - 50)),
		  y: 0,
		  width: 50,
		  height: 75,
		  speed: 2
		};
		srcgamecar_policeCars.push(srcgamecar_newPoliceCar);
	  }, 2000);

	  let srcgamecar_score = 0;
	  let srcgamecar_isGameOver = false;
	  let srcgamecar_gameSpeed = 1;

	  function srcgamecar_update() {
		if (srcgamecar_isGameOver) {
		  return;
		}

		// Increase game speed as score increases
		if (srcgamecar_score >= 5) {
		  srcgamecar_gameSpeed = 2;
		}
		if (srcgamecar_score >= 10) {
		  srcgamecar_gameSpeed = 3;
		}
		if (srcgamecar_score >= 15) {
		  srcgamecar_gameSpeed = 4;
		}
		if (srcgamecar_score >= 20) {
		  srcgamecar_gameSpeed = 5;
		}

		// Clear canvas
		srcgamecar_ctx.clearRect(0, 0, srcgamecar_canvas.width, srcgamecar_canvas.height);

		// Move player car
		if (srcgamecar_keys.left) {
		  srcgamecar_player.x -= srcgamecar_player.speed;
		} else if (srcgamecar_keys.right) {
		  srcgamecar_player.x += srcgamecar_player.speed;
		}

		// Draw player car
		srcgamecar_ctx.fillStyle = "blue";
		srcgamecar_ctx.fillRect(srcgamecar_player.x, srcgamecar_player.y, srcgamecar_player.width, srcgamecar_player.height);

		// Move police cars
		srcgamecar_policeCars.forEach((srcgamecar_policeCar, srcgamecar_index) => {
		  srcgamecar_policeCar.y += srcgamecar_policeCar.speed * srcgamecar_gameSpeed;

		  // Check for collision with player car
		  if (srcgamecar_detectCollision(srcgamecar_player, srcgamecar_policeCar)) {
			srcgamecar_isGameOver = true;
			return;
		  }

		  // Draw police car
		  srcgamecar_ctx.fillStyle = "red";
		  srcgamecar_ctx.fillRect(srcgamecar_policeCar.x, srcgamecar_policeCar.y, srcgamecar_policeCar.width, srcgamecar_policeCar.height);

		  // Remove police car from array if it goes off screen
		  if (srcgamecar_policeCar.y > srcgamecar_canvas.height) {
			srcgamecar_policeCars.splice(srcgamecar_index, 1);
			srcgamecar_score++;
		  }
		});

		// Update score
		srcgamecar_ctx.font = "24px Arial";
		srcgamecar_ctx.fillStyle = "white";
		srcgamecar_ctx.fillText(`Score: ${srcgamecar_score}`, 10, 30);
	  }

	  function srcgamecar_detectCollision(srcgamecar_obj1, srcgamecar_obj2) {
		if (
		  srcgamecar_obj1.x < srcgamecar_obj2.x + srcgamecar_obj2.width &&
		  srcgamecar_obj1.x + srcgamecar_obj1.width > srcgamecar_obj2.x &&
		  srcgamecar_obj1.y < srcgamecar_obj2.y + srcgamecar_obj2.height &&
		  srcgamecar_obj1.y + srcgamecar_obj1.height > srcgamecar_obj2.y
		) {
		  return true;
		}
		return false;
	  }

	  // Keyboard input handling
	  const srcgamecar_keys = {
		left: false,
		right: false
	  };
	  document.addEventListener("keydown", event => {
		if (event.key === "ArrowLeft") {
		  srcgamecar_keys.left = true;
		} else if (event.key === "ArrowRight") {
		  srcgamecar_keys.right = true;
		}
	  });
	  document.addEventListener("keyup", event => {
		if (event.key === "ArrowLeft") {
		  srcgamecar_keys.left = false;
		} else if (event.key === "ArrowRight") {
		  srcgamecar_keys.right = false;
		}

		// Display score
		srcgamecar_ctx.fillStyle = "white";
		srcgamecar_ctx.font = "20px Arial";
		srcgamecar_ctx.fillText("Score: " + srcgamecar_score, 10, 30);
	  });

	  setInterval(srcgamecar_update, 1000 / 60);
	</script>
	
	
</body>
</html>




