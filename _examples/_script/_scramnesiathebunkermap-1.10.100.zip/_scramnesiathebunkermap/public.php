<?php
	/* 
		 _               __ _    _    ___ __  __ ___ 
		| |__ _  _ __ _ / _(_)__| |_ / __|  \/  / __|
		| '_ \ || / _` |  _| (_-< ' \ (__| |\/| \__ \
		|_.__/\_,_\__, |_| |_/__/_||_\___|_|  |_|___/
				  |___/                              

		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
		
		File Description:
			Example of a Public Page Script.
			Can be viewed directly by hardlinking or connected via iframe!
			No Variables are pre-loaded here. you need to include Libraries and other 
			functionalities on your own if necessary.
			You can include settings.php to get the object array with all functionalities and
			the current site initiated variables
	*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
	 <link rel="stylesheet" href="../../_core/_vendor/leafletjs/leaflet.css"
		 crossorigin=""/>

	 <script src="../../_core/_vendor/leafletjs/leaflet.js"
		 crossorigin=""></script> 
    <meta charset="UTF-8">
    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Amnesia: The Bunker - Map</title>
</head>
<body>
		<div id="map" style="min-height: 580px; height: 580px;"></div>
		<script>
			// create the slippy map
			var map = L.map('map', {
				minZoom: 1,
				maxZoom: 4,
				center: [0, 0],
				zoom: 1,
				crs: L.CRS.Simple,
			});

			// dimensions of the image
			var w = 2468,
				h = 1836,
				url = './map.jpg';

			// calculate the edges of the image, in coordinate space
			var southWest = map.unproject([0, h], map.getMaxZoom() - 1);
			var northEast = map.unproject([w, 0], map.getMaxZoom() - 1);
			var bounds = new L.LatLngBounds(southWest, northEast);

			// add the image overlay, 
			// so that it covers the entire map
			L.imageOverlay(url, bounds).addTo(map);

			// tell leaflet that the map is exactly as big as the image
			map.setMaxBounds(bounds);


			var popup = L.popup();

			function onMapClick(e) {
				return false;
				popup
					.setLatLng(e.latlng)
					.setContent("You clicked the map at " + e.latlng.toString())
					.openOn(map);
			}

			map.on('click', onMapClick);

			var polygon = L.polygon([
				[-66.75, 79.375],
				[-66.625, 97.75],
				[-89, 97.125],
				[-88.9375, 79.5625]
			]).addTo(map);

			var polygon1 = L.polygon([
				[-191.5, 119.625],
				[-191.125, 144.125],
				[-209.625, 144.625],
				[-209.4375, 119.5625]
			]).addTo(map);

			/*var circle = L.circle([51.508, 200.11], {
				color: 'red',
				fillColor: '#f03',
				fillOpacity: 0.2,
				radius: 100
			}).addTo(map);
			*/
			
			var noteIcon = L.icon({
				iconUrl: './note.jpg',
				iconSize:     [25, 25], // size of the icon
				iconAnchor:   [22, 25], // point of the icon which will correspond to marker's location
				shadowAnchor: [4, 62],  // the same for the shadow
				popupAnchor:  [-3, -26] // point from which the popup should open relative to the iconAnchor
			});
			var mapIcon = L.icon({
				iconUrl: './note.jpg',
				iconSize:     [25, 25], // size of the icon
				iconAnchor:   [22, 25], // point of the icon which will correspond to marker's location
				shadowAnchor: [4, 62],  // the same for the shadow
				popupAnchor:  [-3, -26] // point from which the popup should open relative to the iconAnchor
			});
			var imageIcon = L.icon({
				iconUrl: './image.jpg',
				iconSize:     [25, 25], // size of the icon
				iconAnchor:   [22, 25], // point of the icon which will correspond to marker's location
				shadowAnchor: [4, 62],  // the same for the shadow
				popupAnchor:  [-3, -26] // point from which the popup should open relative to the iconAnchor
			});

			// Prison
			var x2 = L.marker([ -34.25, 79], {icon: mapIcon}).addTo(map);
			x2.bindPopup("Map: Prison Sector");
			var x9 = L.marker([-34.3125, 91.125], {icon: noteIcon}).addTo(map);
			x9.bindPopup("Note: Reynard - Update on Prisoner");
			var x10 = L.marker([ -32.3125, 98.125], {icon: noteIcon}).addTo(map);
			x10.bindPopup("Note: Boysrond - Wrench Location Note");
			var x8 = L.marker([-35, 93.25], {icon: imageIcon}).addTo(map);
			x8.bindPopup("Image: Tunnel Image");
			var x3 = L.marker([ -11.375, 87.875], {icon: noteIcon}).addTo(map);
			x3.bindPopup("Upgrade: Bagpack");
			var x4 = L.marker([-14.75, 95.375], {icon: noteIcon}).addTo(map);
			x4.bindPopup("Special Item: Chain Cutter");
			var x5 = L.marker([-25.375, 101.625], {icon: noteIcon}).addTo(map);
			x5.bindPopup("Chained Door");
			var x6 = L.marker([-32.125, 96.25], {icon: noteIcon}).addTo(map);
			x6.bindPopup("Vent");
			var x7 = L.marker([-30.875, 91], {icon: noteIcon}).addTo(map);
			x7.bindPopup("Cell Control Console");

			// Arsenal
			var x11 = L.marker([ -111.125, 152.5625], {icon: noteIcon}).addTo(map);
			x11.bindPopup("Special Item: Dynamite");
			var x12 = L.marker([-118.625, 133.9375], {icon: noteIcon}).addTo(map);
			x12.bindPopup("Water Pump");
			var x13 = L.marker([-134, 131.5], {icon: noteIcon}).addTo(map);
			x13.bindPopup("Water Pump Switch");
			var x14 = L.marker([-134, 131.5], {icon: noteIcon}).addTo(map);
			x14.bindPopup("Dogtag: DeHay");
			var x15 = L.marker([-141.375, 143.875], {icon: noteIcon}).addTo(map);
			x15.bindPopup("Dogtag: Travers");
			var x16 = L.marker([-111.5, 126.125], {icon: noteIcon}).addTo(map);
			x16.bindPopup("Image: Cutter");
			var x17 = L.marker([-109.75, 121.625], {icon: noteIcon}).addTo(map);
			x17.bindPopup("Map: Arsenal");

			// Tunnels
			var x18 = L.marker([-181.375, 133], {icon: noteIcon}).addTo(map);
			x18.bindPopup("Image: Shotgun Door");
			var x19 = L.marker([-193.875, 124.0625], {icon: noteIcon}).addTo(map);
			x19.bindPopup("Special Item: Detonator");
			var x20 = L.marker([-194.375, 125.5], {icon: noteIcon}).addTo(map);
			x20.bindPopup("Upgrade: Backpack");
			var x21 = L.marker([-192.5625, 101.5625], {icon: noteIcon}).addTo(map);
			x21.bindPopup("Dogtag: Lambert");
			var x22 = L.marker([-192.875, 103.25], {icon: noteIcon}).addTo(map);
			x22.bindPopup("Special Item: Rabbit Toy");
			var x23 = L.marker([-182, 135.1875], {icon: noteIcon}).addTo(map);
			x23.bindPopup("Note: Toussaint - Madness");
			var x24 = L.marker([-180.125, 130.625], {icon: noteIcon}).addTo(map);
			x24.bindPopup("Note: Joubert - Report Noyer");
			var x25 = L.marker([-82.25, 106.375], {icon: noteIcon}).addTo(map);

			// Barracks
			x25.bindPopup("Note: Joubert - Patrol Debrifing");
			var x26 = L.marker([-93.375, 80], {icon: noteIcon}).addTo(map);
			x26.bindPopup("Dogtag: Laval");
			var x27 = L.marker([ -106.625, 68.25], {icon: noteIcon}).addTo(map);
			x27.bindPopup("Vent");
			var x28 = L.marker([ -105.5, 63.375], {icon: noteIcon}).addTo(map);
			x28.bindPopup("Image: Tunnel Map");
			var x29 = L.marker([-60.8125, 77.125], {icon: noteIcon}).addTo(map);
			x29.bindPopup("Note: Golf - I have the Communication");
			var x30 = L.marker([-66.25, 73.6875], {icon: noteIcon}).addTo(map);
			x30.bindPopup("Image: Dance Table");
			var x31 = L.marker([-108.125, 82.625], {icon: noteIcon}).addTo(map);
			x31.bindPopup("Note: Farber - Last Note");
			var x32 = L.marker([-85.25, 71.75], {icon: noteIcon}).addTo(map);
			x32.bindPopup("Door: Lock");
			var x33 = L.marker([-82.25, 74.25], {icon: noteIcon}).addTo(map);
			x33.bindPopup("Note: Marceu - The officers have fled");
			var x34 = L.marker([-69.5, 65.625], {icon: noteIcon}).addTo(map);
			x34.bindPopup("Note: Trembley - Farber Dies");
			var x35 = L.marker([-81.375, 70.9375], {icon: noteIcon}).addTo(map);
			x35.bindPopup("Communications Power Switch");
			var x36 = L.marker([-70.6875, 67.3125], {icon: noteIcon}).addTo(map);
			x36.bindPopup("Radio Transmission");
			var x37 = L.marker([-66.75, 70.375], {icon: noteIcon}).addTo(map);
			x37.bindPopup("Locked Container");
			var x38 = L.marker([ -66.375, 68.625], {icon: noteIcon}).addTo(map);
			x38.bindPopup("Note: Noyer - ");
			var x39 = L.marker([-71.1875, 64.875], {icon: noteIcon}).addTo(map);
			x39.bindPopup("Note: Ozane - Note to Farber");
			var x40 = L.marker([-84.75, 93.125], {icon: noteIcon}).addTo(map);
			x40.bindPopup("Dogtag: Clement");
			var x41 = L.marker([-70.875, 94.25], {icon: noteIcon}).addTo(map);
			x41.bindPopup("Dogtag: Choplin");
			var x42 = L.marker([-87, 95.5], {icon: noteIcon}).addTo(map);
			x42.bindPopup("Note: Clement - Compelled");
			var x43 = L.marker([-85.75, 85.875], {icon: noteIcon}).addTo(map);
			x43.bindPopup("Note: Chemand - Fear and Paranoia");
			var x44 = L.marker([ -80.125, 96.25], {icon: noteIcon}).addTo(map);
			x44.bindPopup("Image: Paris Family");
			var x45 = L.marker([ -82, 109.125], {icon: noteIcon}).addTo(map);
			x45.bindPopup("Image: Barracks Bed Ownership");
			var x46 = L.marker([-77.875, 90.75], {icon: noteIcon}).addTo(map);
			x46.bindPopup("Note: Stafford - Daisy Chained Switches");
			var x47 = L.marker([ -73, 87], {icon: noteIcon}).addTo(map);
			x47.bindPopup("Note: Nicolai - Unsent Letter");
			var x48 = L.marker([-67.625, 91], {icon: noteIcon}).addTo(map);
			x48.bindPopup("Note: Toussaint - Journal");
			var x49 = L.marker([-69.625, 87.625], {icon: noteIcon}).addTo(map);
			x49.bindPopup("Note: Noyer - Part 1");
			var x50 = L.marker([-83.1875, 104.25], {icon: noteIcon}).addTo(map);
			x50.bindPopup("Map: Barracks");
			var x51 = L.marker([-74.625, 222.375], {icon: noteIcon}).addTo(map);


			// Maintenance
			x51.bindPopup("Door Lock");
			var x52 = L.marker([-59.375, 223.375], {icon: noteIcon}).addTo(map);
			x52.bindPopup("Dogtag: Stafford");
			var x53 = L.marker([-69.875, 215.75], {icon: noteIcon}).addTo(map);
			x53.bindPopup("Note: Chanard - I saw its face");
			var x54 = L.marker([-79.875, 216.25], {icon: noteIcon}).addTo(map);
			x54.bindPopup("Dogtag: Alfonso");
			var x55 = L.marker([-80.5, 212.5], {icon: noteIcon}).addTo(map);
			x55.bindPopup("Dogtag: Courso");
			var x56 = L.marker([ -78.625, 208.875], {icon: noteIcon}).addTo(map);
			x56.bindPopup("Dogtag: Slebert");
			var x57 = L.marker([-115.25, 220.25], {icon: noteIcon}).addTo(map);
			x57.bindPopup("Fuel Station");
			var x58 = L.marker([-106.75, 212.75], {icon: noteIcon}).addTo(map);
			x58.bindPopup("Door Lock");
			var x59 = L.marker([-103.375, 238.625], {icon: noteIcon}).addTo(map);
			x59.bindPopup("Pillbox Key");
			var x60 = L.marker([ -98.75, 244.5], {icon: noteIcon}).addTo(map);
			x60.bindPopup("Dogtag: Bardin");
			var x61 = L.marker([-102.75, 242.125], {icon: noteIcon}).addTo(map);
			x61.bindPopup("Note: Lambert - Part 1");
			var x62 = L.marker([-113.5, 204.125], {icon: noteIcon}).addTo(map);
			x62.bindPopup("Note: Chanard - It can hear me");
			var x63 = L.marker([-113.125, 208.625], {icon: noteIcon}).addTo(map);
			x63.bindPopup("Dogtag: Brillant");
			var x64 = L.marker([-105.375, 176.125], {icon: noteIcon}).addTo(map);
			x64.bindPopup("Map: Maintenance");
			var x65 = L.marker([-103.875, 193.625], {icon: noteIcon}).addTo(map);
			x65.bindPopup("Dogtag: Fortin");
			var x66 = L.marker([-104.375, 187.5], {icon: noteIcon}).addTo(map);
			x66.bindPopup("Upgrade: Backpack");
			var x67 = L.marker([-104.625, 185.375], {icon: noteIcon}).addTo(map);
			x67.bindPopup("Vent");
			var x68 = L.marker([-97.875, 184.625], {icon: noteIcon}).addTo(map);
			x68.bindPopup("Dogtag: Dossier");
			var x69 = L.marker([ -86.875, 186.625], {icon: noteIcon}).addTo(map);
			x69.bindPopup("Dogtag: Giraud");
			var x70 = L.marker([ -85, 185.25], {icon: noteIcon}).addTo(map);
			x70.bindPopup("Image: Fuel Bottle Creation");
			var x71 = L.marker([-104.375, 179.125], {icon: noteIcon}).addTo(map);
			x71.bindPopup("Image: Burn Bodies");
			var x72 = L.marker([-87.375, 184.75], {icon: noteIcon}).addTo(map);
			x72.bindPopup("Note: Stafford - Note to a dead friend");
			var x73 = L.marker([-105.5, 177.9375], {icon: noteIcon}).addTo(map);
			x73.bindPopup("Note: Chanard - The rats");
			var x74 = L.marker([-35.125, 146.25], {icon: noteIcon}).addTo(map);

			// Start Area
			var x1 = L.marker([-41.625, 168.625], {icon: noteIcon}).addTo(map);
			x1.bindPopup("Special Item: Flashlight");
			x74.bindPopup("Power Generator");
			var x75 = L.marker([-23.375, 141], {icon: noteIcon}).addTo(map);
			x75.bindPopup("Bunker Exit");
			var x76 = L.marker([-45.25, 141.5], {icon: noteIcon}).addTo(map);
			x76.bindPopup("Note: Boisrond - How to get the hell out of here");
			var x77 = L.marker([ -41.625, 156.5], {icon: noteIcon}).addTo(map);
			x77.bindPopup("Note: Dr.Josinski - Amnesia Cause");
			var x78 = L.marker([ -41.5, 167.125], {icon: noteIcon}).addTo(map);
			x78.bindPopup("Note: Clement - Agony");
			var x79 = L.marker([-38.6875, 167.9375], {icon: noteIcon}).addTo(map);
			x79.bindPopup("Chained Container");
			var x80 = L.marker([-45.125, 169], {icon: noteIcon}).addTo(map);
			x80.bindPopup("Image: Corpse");
			var x81 = L.marker([ -45, 167.4375], {icon: noteIcon}).addTo(map);
			x81.bindPopup("Note: Dr.Josinksi - Autopsy Reynardt");
			var x82 = L.marker([ -51.6875, 158.625], {icon: noteIcon}).addTo(map);
			x82.bindPopup("Door Lock");
			var x83 = L.marker([-62.375, 163.875], {icon: noteIcon}).addTo(map);
			x83.bindPopup("Special Item: Gun");
			var x84 = L.marker([-50.625, 145.875], {icon: noteIcon}).addTo(map);
			x84.bindPopup("Dogtag: Batiste");
			var x85 = L.marker([-46.25, 145.5], {icon: noteIcon}).addTo(map);
			x85.bindPopup("Storage Container");
			var x86 = L.marker([-46.8125, 151.8125], {icon: noteIcon}).addTo(map);
			x86.bindPopup("Note: Dr.Josinski - Rats and Corpses");
			var x87 = L.marker([-52, 146.75], {icon: noteIcon}).addTo(map);
			x87.bindPopup("Note: Frilous - Note about Dog Tag Codes");
			var x88 = L.marker([-37.3125, 149.125], {icon: noteIcon}).addTo(map);
			x88.bindPopup("Note: Boisrond - Fuel and Fire");
			var x89 = L.marker([-35.25, 147.8125], {icon: noteIcon}).addTo(map);
			x89.bindPopup("Note: Unknown - Keep the lights on");
			var x90 = L.marker([-36.1875, 145.1875], {icon: noteIcon}).addTo(map);
			x90.bindPopup("Special Item: Stop Watch");
			var x91 = L.marker([-37.4375, 146.4375], {icon: noteIcon}).addTo(map);
			x91.bindPopup("Dogtag: Friloux");
			var x92 = L.marker([-56.875, 126.875], {icon: noteIcon}).addTo(map);
			x92.bindPopup("Emergency Lockdown Release");
			var x93 = L.marker([-57.375, 121], {icon: noteIcon}).addTo(map);
			x93.bindPopup("Emergency Lockdown");
			var x94 = L.marker([-43.3125, 109.125], {icon: noteIcon}).addTo(map);
			x94.bindPopup("Emergency Lockdown");
			var x95 = L.marker([-67, 166.125], {icon: noteIcon}).addTo(map);
			x95.bindPopup("Dogtag: Delisle");
			var x96 = L.marker([-38.875, 124.625], {icon: noteIcon}).addTo(map);
			x96.bindPopup("Dogtag: AuClair");
			var x97 = L.marker([-76.8125, 167], {icon: noteIcon}).addTo(map);
			x97.bindPopup("Dogtag: Boucher");
			var x98 = L.marker([-79.1875, 178.125], {icon: noteIcon}).addTo(map);
			x98.bindPopup("Vent");
			var x99 = L.marker([-79.25, 176], {icon: noteIcon}).addTo(map);
			x99.bindPopup("Chained Door");
			var x100 = L.marker([-81.4375, 160.3125], {icon: noteIcon}).addTo(map);
			x100.bindPopup("Chained Container");
			var x101 = L.marker([-68.1875, 169.875], {icon: noteIcon}).addTo(map);
			x101.bindPopup("Upgrade: Backpack");
			var x102 = L.marker([ -81.6875, 166.6875], {icon: noteIcon}).addTo(map);
			x102.bindPopup("Emergency Lockdown");
			var x103 = L.marker([ -81.4375, 141.0625], {icon: noteIcon}).addTo(map);
			x103.bindPopup("Emergency Lockdown");
			var x104 = L.marker([ -78.375, 145], {icon: noteIcon}).addTo(map);
			x104.bindPopup("Note: Delpy - Prisoner in Custody");
			var x105 = L.marker([-79.25, 151.25], {icon: noteIcon}).addTo(map);
			x105.bindPopup("Image: Roman Tunnels");
		</script>
</body>
</html>




