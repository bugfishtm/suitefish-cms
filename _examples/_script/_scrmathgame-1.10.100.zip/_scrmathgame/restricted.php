<?php
	/* 
		 _               __ _    _    ___ __  __ ___ 
		| |__ _  _ __ _ / _(_)__| |_ / __|  \/  / __|
		| '_ \ || / _` |  _| (_-< ' \ (__| |\/| \__ \
		|_.__/\_,_\__, |_| |_/__/_||_\___|_|  |_|___/
				  |___/                              

		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
		
		File Description:
			Restricted Example Script PHP Script.
			Can be included via PHP Require_once and you can write code here which will be executed.
			You will have access to all site modules variables.
	*/ if(!is_array($object)) { @http_response_code(404); echo "No hardlinking allowed!"; exit(); }
?>
<script>
    // Define a function to generate a random math problem
    function srcmathgame_generateProblem() {
      // Generate two random numbers between 1 and 10
      var srcmathgame_num1 = Math.floor(Math.random() * 10) + 1;
      var srcmathgame_num2 = Math.floor(Math.random() * 10) + 1;

      // Generate a random operator (+, -, *)
      var srcmathgame_operators = ['+', '-', '*'];
      var srcmathgame_operator = srcmathgame_operators[Math.floor(Math.random() * srcmathgame_operators.length)];

      // Generate the problem as a string
      var srcmathgame_problem = srcmathgame_num1 + ' ' + srcmathgame_operator + ' ' + srcmathgame_num2;

      // Calculate the answer
      var srcmathgame_answer;
      switch (srcmathgame_operator) {
        case '+':
          srcmathgame_answer = srcmathgame_num1 + srcmathgame_num2;
          break;
        case '-':
          srcmathgame_answer = srcmathgame_num1 - srcmathgame_num2;
          break;
        case '*':
          srcmathgame_answer = srcmathgame_num1 * srcmathgame_num2;
          break;
      }

      // Return the problem and the answer as an object
      return {
        problem: srcmathgame_problem,
        answer: srcmathgame_answer
      };
    }

    // Initialize the game
    var srcmathgame_score = 0;
    var srcmathgame_currentProblem;

    function srcmathgame_startGame() {
      // Show the problem and answer elements
      document.getElementById('srcmathgame_problem').style.display = 'block';
      document.getElementById('srcmathgame_answer').style.display = 'block';
      document.getElementById('srcmathgame_submit-answer').style.display = 'block';

      // Generate the first problem and display it
      srcmathgame_currentProblem = srcmathgame_generateProblem();
      document.getElementById('srcmathgame_problem').textContent = srcmathgame_currentProblem.problem;

      // Add an event listener to the submit button
      document.getElementById('srcmathgame_submit-answer').addEventListener('click', srcmathgame_submitAnswer);

      // Add an event listener to the answer input field
      document.getElementById('srcmathgame_answer').addEventListener('keyup', function(event) {
        if (event.keyCode === 13) {
          event.preventDefault();
          document.getElementById('srcmathgame_submit-answer').click();
        }
      });
    }

    function srcmathgame_submitAnswer() {
      // Get the user's answer
      var srcmathgame_userAnswer = parseInt(document.getElementById('srcmathgame_answer').value);

      // Check the user's answer and update the score
      if (srcmathgame_userAnswer === srcmathgame_currentProblem.answer) {
        srcmathgame_score += 10;
        document.getElementById('srcmathgame_score').textContent = 'Score: ' + srcmathgame_score;

        // Generate a new problem and display it
        srcmathgame_currentProblem = srcmathgame_generateProblem();
        document.getElementById('srcmathgame_problem').textContent = srcmathgame_currentProblem.problem;
      }

      // Clear the answer input
      document.getElementById('srcmathgame_answer').value = '';
    }
  </script>
    <div style="text-align: center; margin: auto; width: 100%;">
		<div style="">
		  <h3>Math Game</h3>
		  <p>Answer the math problems below to earn points. Click "Start Game" to begin!</p>
		  <button id="srcmathgame_start-game" onclick="srcmathgame_startGame()">Start Game</button><hr>
		  <div id="srcmathgame_problem" style="display: none;"></div>
		  <center>	
			<input type="number" id="srcmathgame_answer" style="display: none;width: 100%; max-width:400px;"><br />
			<button id="srcmathgame_submit-answer" style="display: none;width: 100%; max-width:400px;">Submit Answer</button><br />
		  </center>
		  <div id="srcmathgame_score">Score: 0</div>
		</div>
    </div>