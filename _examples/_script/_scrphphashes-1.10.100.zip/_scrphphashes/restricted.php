<?php
	/* 
		 _               __ _    _    ___ __  __ ___ 
		| |__ _  _ __ _ / _(_)__| |_ / __|  \/  / __|
		| '_ \ || / _` |  _| (_-< ' \ (__| |\/| \__ \
		|_.__/\_,_\__, |_| |_/__/_||_\___|_|  |_|___/
				  |___/                              

		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
		
		File Description:
			Restricted Example Script PHP Script.
			Can be included via PHP Require_once and you can write code here which will be executed.
			You will have access to all site modules variables.
	*/ if(!is_array($object)) { @http_response_code(404); echo "No hardlinking allowed!"; exit(); }
?>
    <div style="text-align: center; margin: auto; width: 100%;">

		<div class='xfp_content_box_text xfpe_aligncenter'><label>Enter a String to Encrypt:</label><br/>
		<form method="post"><input type="text" name="php_string"><input type="submit" value="Encrypt" class="x_fp_primary_button"></form><br />
		<?php if(isset($_POST["php_string"])) {
			echo '<b>Argon2i-Hash</b><br /><textarea class="xfpe_width100pct" readonly>' . password_hash(@$_POST["php_string"], PASSWORD_ARGON2I)."</textarea> <br /><br />";
			echo '<b>BCrypt-Hash</b><br /><textarea class="xfpe_width100pct" readonly>' . password_hash(@$_POST["php_string"], PASSWORD_BCRYPT)."</textarea> <br /><br />";
			echo '<b>Argon2iD-Hash</b><br /><textarea class="xfpe_width100pct" readonly>' . password_hash(@$_POST["php_string"], PASSWORD_ARGON2ID)."</textarea> <br /><br />";
		} ?>


		<?php if(isset($_POST["php_string"])) {echo "<b>Youre MD5 String: </b><br /><textarea class='xfpe_width100pct' readonly>".md5(@$_POST["php_string"])."</textarea>";} ?></div>
			
    </div>