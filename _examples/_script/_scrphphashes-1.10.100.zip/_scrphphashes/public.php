<?php
	/* 
		 _               __ _    _    ___ __  __ ___ 
		| |__ _  _ __ _ / _(_)__| |_ / __|  \/  / __|
		| '_ \ || / _` |  _| (_-< ' \ (__| |\/| \__ \
		|_.__/\_,_\__, |_| |_/__/_||_\___|_|  |_|___/
				  |___/                              

		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
		
		File Description:
			Example of a Public Page Script.
			Can be viewed directly by hardlinking or connected via iframe!
			No Variables are pre-loaded here. you need to include Libraries and other 
			functionalities on your own if necessary.
			You can include settings.php to get the object array with all functionalities and
			the current site initiated variables
	*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Hashes</title>
    <style>
        body, html {
            height: 100%;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        .centered-content {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="centered-content" style="max-width: 400px;">
	
	
	
	
<div class='xfp_content_box_text xfpe_aligncenter'><label>Enter a String to Encrypt:</label><br/>
<form method="post"><input type="text" name="php_string"><input type="submit" value="Encrypt" class="x_fp_primary_button"></form><br />
<?php if(isset($_POST["php_string"])) {
	echo '<b>Argon2i-Hash</b><br /><textarea style="width: 100%; max-width: 500px;" readonly>' . password_hash(@$_POST["php_string"], PASSWORD_ARGON2I)."</textarea> <br /><br />";
	echo '<b>BCrypt-Hash</b><br /><textarea style="width: 100%; max-width: 500px;" readonly>' . password_hash(@$_POST["php_string"], PASSWORD_BCRYPT)."</textarea> <br /><br />";
	echo '<b>Argon2iD-Hash</b><br /><textarea style="width: 100%; max-width: 500px;" readonly>' . password_hash(@$_POST["php_string"], PASSWORD_ARGON2ID)."</textarea> <br /><br />";
} ?>


<?php if(isset($_POST["php_string"])) {echo "<b>Youre MD5 String: </b><br /><textarea style='width: 100%; max-width: 500px;' readonly>".md5(@$_POST["php_string"])."</textarea>";} ?></div>
    
	
	
	</div>	
</body>
</html>






