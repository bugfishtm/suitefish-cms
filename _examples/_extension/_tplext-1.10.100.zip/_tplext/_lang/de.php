<?php if(isset($this)) { if(!is_object($this)) { exit(); } } else { exit(); }
#		@@@@@@@   @@@  @@@   @@@@@@@@  @@@@@@@@  @@@   @@@@@@   @@@  @@@  
#		@@@@@@@@  @@@  @@@  @@@@@@@@@  @@@@@@@@  @@@  @@@@@@@   @@@  @@@  
#		@@!  @@@  @@!  @@@  !@@        @@!       @@!  !@@       @@!  @@@  
#		!@   @!@  !@!  @!@  !@!        !@!       !@!  !@!       !@!  @!@  
#		@!@!@!@   @!@  !@!  !@! @!@!@  @!!!:!    !!@  !!@@!!    @!@!@!@!  
#		!!!@!!!!  !@!  !!!  !!! !!@!!  !!!!!:    !!!   !!@!!!   !!!@!!!!  
#		!!:  !!!  !!:  !!!  :!!   !!:  !!:       !!:       !:!  !!:  !!!  
#		:!:  !:!  :!:  !:!  :!:   !::  :!:       :!:      !:!   :!:  !:!  
#		 :: ::::  ::::: ::   ::: ::::   ::        ::  :::: ::   ::   :::  
#		:: : ::    : :  :    :: :: :    :        :    :: : :     :   : :  www.bugfish.eu?>
##########################################################################################
## Extension Related
##########################################################################################

nav_title=Beispielerweiterung

site_title=Beispielerweiterung
site_title1=Beispiel-Admin-Seite für das Modul _tplext Erweiterung.
site_title2=Dies ist nur eine Testseite für das Beispielmodul!
site_title3=Sie haben keinen Zugriff auf diese Seite!

site_settings=Für dieses Modul sind keine Einstellungen verfügbar! Die in diesem Modul enthaltene Datei "mod_setting" ist nur ein Beispiel dafür, wie Inhalte auf einer Verwaltungsseite angezeigt werden können.

example_permission=Beispiel-Erweiterungsadmin
example_permission_descr=Kann die Admin-Seite für die Beispielerweiterung anzeigen.
