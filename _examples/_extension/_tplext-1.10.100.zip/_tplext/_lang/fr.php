<?php if(isset($this)) { if(!is_object($this)) { exit(); } } else { exit(); }
#		@@@@@@@   @@@  @@@   @@@@@@@@  @@@@@@@@  @@@   @@@@@@   @@@  @@@  
#		@@@@@@@@  @@@  @@@  @@@@@@@@@  @@@@@@@@  @@@  @@@@@@@   @@@  @@@  
#		@@!  @@@  @@!  @@@  !@@        @@!       @@!  !@@       @@!  @@@  
#		!@   @!@  !@!  @!@  !@!        !@!       !@!  !@!       !@!  @!@  
#		@!@!@!@   @!@  !@!  !@! @!@!@  @!!!:!    !!@  !!@@!!    @!@!@!@!  
#		!!!@!!!!  !@!  !!!  !!! !!@!!  !!!!!:    !!!   !!@!!!   !!!@!!!!  
#		!!:  !!!  !!:  !!!  :!!   !!:  !!:       !!:       !:!  !!:  !!!  
#		:!:  !:!  :!:  !:!  :!:   !::  :!:       :!:      !:!   :!:  !:!  
#		 :: ::::  ::::: ::   ::: ::::   ::        ::  :::: ::   ::   :::  
#		:: : ::    : :  :    :: :: :    :        :    :: : :     :   : :  www.bugfish.eu?>
##########################################################################################
## Extension Related
##########################################################################################

nav_title=Extension Exemple

site_title=Extension Exemple
site_title1=Page d'administration exemple pour le module _tplext Extension.
site_title2=Ceci est simplement un site de test pour le module Exemple !
site_title3=Vous n'avez pas accès à cette page !

site_settings=Aucun paramètre n'est disponible pour ce module ! Le fichier mod_setting inclus dans ce module est simplement un exemple de génération de contenu sur une page administrative.

example_permission=Administrateur de l'extension Exemple
example_permission_descr=Peut voir la page d'administration de l'extension Exemple.
