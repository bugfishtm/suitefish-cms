<?php if(isset($this)) { if(!is_object($this)) { exit(); } } else { exit(); }
#		@@@@@@@   @@@  @@@   @@@@@@@@  @@@@@@@@  @@@   @@@@@@   @@@  @@@  
#		@@@@@@@@  @@@  @@@  @@@@@@@@@  @@@@@@@@  @@@  @@@@@@@   @@@  @@@  
#		@@!  @@@  @@!  @@@  !@@        @@!       @@!  !@@       @@!  @@@  
#		!@   @!@  !@!  @!@  !@!        !@!       !@!  !@!       !@!  @!@  
#		@!@!@!@   @!@  !@!  !@! @!@!@  @!!!:!    !!@  !!@@!!    @!@!@!@!  
#		!!!@!!!!  !@!  !!!  !!! !!@!!  !!!!!:    !!!   !!@!!!   !!!@!!!!  
#		!!:  !!!  !!:  !!!  :!!   !!:  !!:       !!:       !:!  !!:  !!!  
#		:!:  !:!  :!:  !:!  :!:   !::  :!:       :!:      !:!   :!:  !:!  
#		 :: ::::  ::::: ::   ::: ::::   ::        ::  :::: ::   ::   :::  
#		:: : ::    : :  :    :: :: :    :        :    :: : :     :   : :  www.bugfish.eu?>
##########################################################################################
## Extension Related
##########################################################################################

nav_title=Estensione di esempio

site_title=Estensione di esempio
site_title1=Pagina di amministrazione di esempio per il modulo _tplext Estensione.
site_title2=Questo è solo un sito di prova per il modulo di esempio!
site_title3=Non hai accesso a questa pagina!

site_settings=Non sono disponibili impostazioni per questo modulo! Il file mod_setting incluso in questo modulo è solo un esempio di come generare contenuti su una pagina amministrativa.

example_permission=Amministratore dell'estensione di esempio
example_permission_descr=Può visualizzare la pagina di amministrazione per l'estensione di esempio.
