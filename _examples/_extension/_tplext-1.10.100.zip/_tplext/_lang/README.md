# Translation Files

Additional Translations for this Site Modules Extension.

Happy Coding!  
Bugfish <3 