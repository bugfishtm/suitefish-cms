<?php if(isset($this)) { if(!is_object($this)) { exit(); } } else { exit(); }
#		@@@@@@@   @@@  @@@   @@@@@@@@  @@@@@@@@  @@@   @@@@@@   @@@  @@@  
#		@@@@@@@@  @@@  @@@  @@@@@@@@@  @@@@@@@@  @@@  @@@@@@@   @@@  @@@  
#		@@!  @@@  @@!  @@@  !@@        @@!       @@!  !@@       @@!  @@@  
#		!@   @!@  !@!  @!@  !@!        !@!       !@!  !@!       !@!  @!@  
#		@!@!@!@   @!@  !@!  !@! @!@!@  @!!!:!    !!@  !!@@!!    @!@!@!@!  
#		!!!@!!!!  !@!  !!!  !!! !!@!!  !!!!!:    !!!   !!@!!!   !!!@!!!!  
#		!!:  !!!  !!:  !!!  :!!   !!:  !!:       !!:       !:!  !!:  !!!  
#		:!:  !:!  :!:  !:!  :!:   !::  :!:       :!:      !:!   :!:  !:!  
#		 :: ::::  ::::: ::   ::: ::::   ::        ::  :::: ::   ::   :::  
#		:: : ::    : :  :    :: :: :    :        :    :: : :     :   : :  www.bugfish.eu?>
##########################################################################################
## Extension Related
##########################################################################################

nav_title=Extensión de ejemplo

site_title=Extensión de ejemplo
site_title1=Página de administración de ejemplo para el módulo _tplext extensión.
site_title2=¡Este es solo un sitio de prueba para el módulo de ejemplo!
site_title3=¡No tienes acceso a esta página!

site_settings=¡No hay configuraciones disponibles para este módulo! El archivo mod_setting incluido en este módulo es solo un ejemplo de cómo generar contenido en una página administrativa.

example_permission=Administrador de extensión de ejemplo
example_permission_descr=Puede ver la página de administración de la extensión de ejemplo.
