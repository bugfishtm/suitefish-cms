<?php
	/* 	 _           ___ _     _   _____ _____ _____ 
		| |_ _ _ ___|  _|_|___| |_|     |     |   __|
		| . | | | . |  _| |_ -|   |   --| | | |__   |
		|___|___|_  |_| |_|___|_|_|_____|_|_|_|_____|
				|___|                                
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.
		
		File Description:
			Versioning File to Contain Module Information!
	*/	
	$x = array();

	##############################
	// Module Various Informations
	##############################
	
		// Module Unique ID
		// Unique Module Identifier (should NEVER be the same on 2 different modules)
		// You can ask at requests@bugfish.eu for your unique module identifiert to provide 
		// Modules to an official online store.
		// Do not use special chars, no more than 10 signs for rname of this module type!
		$x["rname"] 		= "_tplkimai";
		
		// Module Language
		// Available Languages in this Module Array (shortcodes)
		$x["lang"] 			= array("en");
		
		// Database Build Information.
		// This Number will be used for updater script
		// to determine if update is needed and build number is stored
		// for active site module in database together with rname
		$x["build"] 		= "100";
		
		// Version Number, only imaginary (has to end with build number)
		$x["version"] 		= "2.21.0.".$x["build"];
		
		// Module Title and Name
		$x["name"] 			= "Docker: Kimai";
		
		// Short Description
		$x["short"] 		= "Kimai is a free and open-source time-tracking software designed for freelancers and small businesses. Written in PHP, it allows users to efficiently track work hours, manage projects, and generate invoices, all while providing a user-friendly interface and customizable features.";
		
		// Module Full Description 
		$x["description"] 	= "Kimai is a powerful, web-based time-tracking application that caters to the needs of freelancers, agencies, and companies of all sizes. As an open-source solution, Kimai offers users the flexibility to self-host or utilize a subscription-based SaaS model. The software is built in PHP and supports an unlimited number of users, clients, and projects, making it ideal for diverse business environments. With features such as multi-user support, customizable roles and permissions, invoicing capabilities, and extensive reporting tools, Kimai streamlines the process of tracking work hours and managing projects. Users can easily create timesheets, generate invoices from their tracked time, and export data in various formats. Additionally, Kimai's responsive design ensures compatibility across devices, allowing users to access their time-tracking data anytime and anywhere.";
		
		// Module Type
		// 1 - Site Module
		// 2 - Public Application Modul
		// 3 - Extension for RNAME
		// 4 - Image Module
		// 5 - Docker Image Module
		$x["type"] 			= 5;
		
		// Parent Module
		// If this Extension/Module is related to a Parent Extension/Module enter the Parent rname below!
		// This can be an array("mod", "mod") or string for a single module
		$x["parent_rname"] 	= false;

		// Single Instance Module?
		// If true, than this modules rname can only be deployed a single time on that cms instance.
		// Recommended for Server Software where duplications of the module activated may lead to issues.
		// Module will be forced to use RNAME as Site Module Name
		$x["single_instance"] 	= false;	

	##############################
	// Module Autor Informations
	##############################
	
		// Module License (gplv3, gplv2, mit, bsd, bsd2, ...)
		$x["license"] 		= "agpl3";
		
		// Module Autor Name
		$x["autor"] 		= "Kimai";
		
		// Module Autor Mail
		$x["mail"] 			= "No Contact Mail";
		
		// Module Autor Website
		$x["website"] 		= "www.kimai.org";
	