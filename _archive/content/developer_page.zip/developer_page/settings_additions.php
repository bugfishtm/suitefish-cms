
		
		// Set enable/disable for developer.php file on Start if not defined
		if(!defined("_HIVE_MOD_CHANGES_")) 						{ define('_HIVE_MOD_CHANGES_', false); }
		
		