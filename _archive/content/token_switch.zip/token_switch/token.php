<?php
	/* 
		 ____  __  __  ___  ____  ____  ___  _   _ 
		(  _ \(  )(  )/ __)( ___)(_  _)/ __)( )_( )
		 ) _ < )(__)(( (_-. )__)  _)(_ \__ \ ) _ ( 
		(____/(______)\___/(__)  (____)(___/(_) (_) www.bugfish.eu
				 ___ _   _ ___ _____ ___ ___ ___ ___ _  _ 
				/ __| | | |_ _|_   _| __| __|_ _/ __| || |
				\__ \ |_| || |  | | | _|| _| | |\__ \ __ |
				|___/\___/|___| |_| |___|_| |___|___/_||_|
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
	*/
	if(!is_array(@$object)) { @http_response_code(404); Header("Location: ../"); exit(); } 	
		////////////////////////////////////////////////////////////////////////////////////////////////	
		// Variables
		////////////////////////////////////////////////////////////////////////////////////////////////		
		$title_general 	= $object["lang"]->translate("adm_nav_module_token");
		$trts_general 	= "site_mode, token_key, id";
		$table_general 	= _TABLE_TOKEN_;
		$table_title   	= array(array("name" => $object["lang"]->translate("string_module")),
							   array("name" => $object["lang"]->translate("string_password")),
							   array("name" => $object["lang"]->translate("string_operation")));
							   
		////////////////////////////////////////////////////////////////////////////////////////////////		
		// Create Table Object
		////////////////////////////////////////////////////////////////////////////////////////////////		
		$tbl = new x_class_table($object["mysql"], $table_general, "table");

		////////////////////////////////////////////////////////////////////////////////////////////////		
		// Operations
		////////////////////////////////////////////////////////////////////////////////////////////////			
		if(is_numeric(@$_POST["add_form_exec"])) { 
			if($object["csrf"]->check(@$_POST["token"])) {
				$b = array();
				$b[0]["value"] = @$_POST["form_edit_module"];
				$b[1]["value"] = @$_POST["form_edit_pass"];
				$xm = $object["mysql"]->select("SELECT * FROM "._TABLE_TOKEN_." WHERE `site_mode` = ? OR token_key = ?", false, $b);
				if(!$xm) { 
					$b = array();
					$b[0]["value"] = @$_POST["form_edit_module"];
					$b[1]["value"] = @$_POST["form_edit_pass"];
					$object["mysql"]->query("INSERT INTO "._TABLE_TOKEN_."(site_mode, token_key) VALUES(?, ?);", $b);
					$object["eventbox"]->ok($object["lang"]->translate("event_operation_success"));
					Header("Location: ./?l1="._HIVE_URL_CUR_[0]."&l2="._HIVE_URL_CUR_[1]."");
					exit();				
				} else {
					$object["eventbox"]->error($object["lang"]->translate("event_error_exists"));
					Header("Location: ./?l1="._HIVE_URL_CUR_[0]."&l2="._HIVE_URL_CUR_[1]."");
					exit();
				}				
			} else {
				$object["eventbox"]->error($object["lang"]->translate("event_csrf"));
				Header("Location: ./?l1="._HIVE_URL_CUR_[0]."&l2="._HIVE_URL_CUR_[1]."");
				exit();
			}
		}
		
		$delete_confirm = false;
		if(is_numeric(@$_GET["delete_id"])) {
			if(@$_GET["confirmation"] == "true") { 
				if($object["csrf"]->check(@$_POST["token"])) {
					$xm = $object["mysql"]->select("SELECT * FROM "._TABLE_TOKEN_." WHERE id = ".@$_GET["delete_id"]."", false);
					if(!is_array($xm)) { $xm = array(); }
					$object["mysql"]->query("DELETE FROM "._TABLE_TOKEN_." WHERE id = ".@$_GET["delete_id"]."");
					$object["eventbox"]->ok($object["lang"]->translate("event_deleted"));
					Header("Location: ./?l1="._HIVE_URL_CUR_[0]."&l2="._HIVE_URL_CUR_[1]."");
					exit();
				} else {
					$object["eventbox"]->error($object["lang"]->translate("event_csrf"));
					Header("Location: ./?l1="._HIVE_URL_CUR_[0]."&l2="._HIVE_URL_CUR_[1]."");
					exit();
				}
			} else {
				$xm = $object["mysql"]->select("SELECT * FROM "._TABLE_TOKEN_." WHERE id = ".@$_GET["delete_id"]."", false);
				if(is_array($xm)) { $delete_confirm = true; }
			}
		}

		////////////////////////////////////////////////////////////////////////////////////////////////
		// Header
		////////////////////////////////////////////////////////////////////////////////////////////////				
		adminbsb_header($object, $object["lang"]->translate("adm_nav_module_token")." - ". $object["lang"]->translate("adm_nav_module"));
		echo sf__theme_title($object["lang"]->translate("adm_nav_module_token"), $object["lang"]->translate("adm_nav_module_token_exp"));	

		////////////////////////////////////////////////////////////////////////////////////////////////
		// Space Fix
		////////////////////////////////////////////////////////////////////////////////////////////////		
		echo sf__theme_space_m();

		////////////////////////////////////////////////////////////////////////////////////////////////
		// Popup Delete Item
		////////////////////////////////////////////////////////////////////////////////////////////////		
		if($delete_confirm) {
			?>
			<script>
				Swal.fire({
				  title: "<?php echo $object["lang"]->translate("string_item_delete"); ?>",
				  html: "<?php echo $object["lang"]->translate("string_item_dlrdy"); ?><br /><form method='post' action='<?php echo "./?"._HIVE_URL_GET_[0]."="._HIVE_URL_CUR_[0]."&"._HIVE_URL_GET_[1]."="._HIVE_URL_CUR_[1]."&confirmation=true&delete_id=".@$_GET["delete_id"].""; ?>'><input type='hidden' name='token' value='<?php echo $object["csrf"]->get(); ?>'><br /><input type='submit' class=\"btn btn-primary\" value='<?php echo htmlentities($object["lang"]->translate("string_yes") ?? ''); ?>'> <a href='<?php echo "./?"._HIVE_URL_GET_[0]."="._HIVE_URL_CUR_[0]."&"._HIVE_URL_GET_[1]."="._HIVE_URL_CUR_[1].""; ?>' class='btn btn-danger'><?php echo htmlentities($object["lang"]->translate("string_cancel") ?? ''); ?></a></form>",
				  showCancelButton: false,
				  showCloseButton: true,
				  showConfirmButton: false,
				  icon: "warning",
				  allowOutsideClick: false,
				  willClose: () => {
					window.location.href = '<?php echo hive__url(array("module", "token")); ?>';
				  }
				});
			</script>
			<?php 	
		}

		////////////////////////////////////////////////////////////////////////////////////////////////
		// Add an Item
		////////////////////////////////////////////////////////////////////////////////////////////////
		echo sf__theme_box_start();
			?>
			<a class="btn btn-info" target="_blank" href="./_core/_action/token_switch.php"><?php echo $object["lang"]->translate("string_token_switch"); ?></a> 
			<a class="btn btn-info" target="_blank" href="./_core/_action/admin_switch.php"><?php echo $object["lang"]->translate("string_frontend_switch"); ?></a> 
			<?php
		echo sf__theme_box_end();

		////////////////////////////////////////////////////////////////////////////////////////////////
		// Space Fix
		////////////////////////////////////////////////////////////////////////////////////////////////		
		echo sf__theme_space_fix();
		
		////////////////////////////////////////////////////////////////////////////////////////////////
		// Add an Item
		////////////////////////////////////////////////////////////////////////////////////////////////
		echo sf__theme_box_start("<h2>".$title_general." - ".$object["lang"]->translate("string_create"). "</h2>", "hive__card_collapse");
			?>
			<form action="" method="post">
				<label for="form_edit_lang"><?php echo $object["lang"]->translate("string_module"); ?></label>
				<div class="form-group">
					<select  id="form_edit_lang" class="form-control" name="form_edit_module">
						<?php 
							if(is_array(_HIVE_MODE_ARRAY_)) {
								foreach(_HIVE_MODE_ARRAY_ as $k => $v) {
									echo '<option value="'.$v.'">';
									echo $v;
									echo '</option>';
								}
							}
						?>
					</select>
				</div>			
				<label for="constant_name"><?php echo $object["lang"]->translate("string_password"); ?></label>
				<div class="form-group">
					<div class="form-line">
						<input type="text" id="constant_name" value="" class="form-control" name="form_edit_pass" required>
					 </div>
				</div>							
				<input type="hidden" name="token" value="<?php echo $object["csrf"]->get(); ?>">
				<input type="hidden" name="add_form_exec" value="1">
				<button class="btn btn-info" type="submit"><?php echo $object["lang"]->translate("string_save"); ?></button> 
			</form>
			<?php
		echo sf__theme_box_end();

		////////////////////////////////////////////////////////////////////////////////////////////////
		// Space Fix
		////////////////////////////////////////////////////////////////////////////////////////////////		
		echo sf__theme_space_fix();
	
	
		////////////////////////////////////////////////////////////////////////////////////////////////		
		// Get Table Values
		////////////////////////////////////////////////////////////////////////////////////////////////		
		$value_array = $object["mysql"]->select("SELECT ".$trts_general." FROM ".$table_general."", true);
		if(is_array($value_array)) {
			foreach($value_array as $key => $value) {
				$value_array[$key]["token_key"] = @htmlspecialchars($value_array[$key]["token_key"]);
				$value_array[$key]["site_mode"] = @htmlspecialchars($value_array[$key]["site_mode"]);
				$value_array[$key]["action"] = "<a href='".hive__url(array("module", "token"))."&delete_id=".$value_array[$key]["id"]."' class='btn btn-danger'>".$object["lang"]->translate("string_delete")."</a>";
			}
		}
		
		////////////////////////////////////////////////////////////////////////////////////////////////		
		// Display the Table!
		////////////////////////////////////////////////////////////////////////////////////////////////		
		echo sf__theme_box_start("<h2>".$title_general." - ".$object["lang"]->translate("string_list"). "</h2>");
		$tbl->spawn_table($table_title, $value_array, false, false, false, false, "display");
		echo sf__theme_box_end();

		////////////////////////////////////////////////////////////////////////////////////////////////
		// Space Fix
		////////////////////////////////////////////////////////////////////////////////////////////////		
		echo sf__theme_space_fix();
		
