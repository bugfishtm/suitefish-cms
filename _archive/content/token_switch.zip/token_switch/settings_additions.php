
		// Set enable/disable for _core/_action/token_switch.php file on Start if not defined
			/* REMOVED FROM CFG-RULESET.SAMPLE */		
			// **Token-Based Switches**:
			// - Allows the use of token-based switches via `_core/_action/token_switch.php`.
			// - Default value: `true`.
			// Uncomment and adjust the following line to use:
			// define('_HIVE_ALLOW_TOKEN_', true);		
			/* REMOVED FROM CFG-RULESET.SAMPLE */		
		if(!defined("_HIVE_ALLOW_TOKEN_")) 						{ define('_HIVE_ALLOW_TOKEN_', true);	 }