# Image Extension: Space-Invaders

## 🧩 **General Information**

Space Invaders is a classic arcade game where the player controls a spaceship and shoots down enemy aliens. This simple game is developed using the p5.js library and is open source.

- Use the arrow keys to move the spaceship left and right.
- Press the spacebar to shoot.

## 📚 **Suitefish Image Module**
This is a Suitefish Image Module! Explore suitefish-cms guides, examples, and best practices to get the most out of Suitefish CMS. Whether you're a developer or an admin, you'll find everything you need to get started here: [https://bugfishtm.github.io/suitefish-cms](https://bugfishtm.github.io/suitefish-cms).

## 📜 **License Information**

See the included License.md file for information about this projects license. The game icons from Flaticon free resources.

🐟 Bugfish <3






