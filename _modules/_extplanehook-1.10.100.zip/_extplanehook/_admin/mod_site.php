<?php
	/* 
		 ____  __  __  ___  ____  ____  ___  _   _ 
		(  _ \(  )(  )/ __)( ___)(_  _)/ __)( )_( )
		 ) _ < )(__)(( (_-. )__)  _)(_ \__ \ ) _ ( 
		(____/(______)\___/(__)  (____)(___/(_) (_) www.bugfish.eu
				 ___ _   _ ___ _____ ___ ___ ___ ___ _  _ 
				/ __| | | |_ _|_   _| __| __|_ _/ __| || |
				\__ \ |_| || |  | | | _|| _| | |\__ \ __ |
				|___/\___/|___| |_| |___|_| |___|___/_||_|
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
	*/ if(!is_array(@$object)) { @http_response_code(404); Header("Location: ../"); exit(); }
	
	if(hive__access($object, array($object["extension"]["prefix_variables"]."admin"), false)) { 
	
		////////////////////////////////////////////////////////////////
		// Redirect on URL Change Operation
		////////////////////////////////////////////////////////////////	
		if(@$_GET["op"] == "change_url") {
			if(@$_GET["confirm"] == "confirmed") { 
				if($object["csrf"]->check(@$_POST["hive_submit_flush_table_token"])) { 
					Header("Location: ./?l1="._HIVE_URL_CUR_[0]."");
				}  
			}			
		}			
	
		////////////////////////////////////////////////////////////////
		// Header Elements
		////////////////////////////////////////////////////////////////
		adminbsb_header($object, hive__hsc($object["extension"]["lang"]->translate("site_title")));
		echo sf__theme_title($object["extension"]["lang"]->translate("site_title"), $object["extension"]["lang"]->translate("site_heading_text"));	

		////////////////////////////////////////////////////////////////////////////////////////////////
		// Space Fix
		////////////////////////////////////////////////////////////////////////////////////////////////		
		echo sf__theme_space_m();
	
		////////////////////////////////////////////////////////////////
		// Variables
		////////////////////////////////////////////////////////////////
		$table_general 	= $object["extension"]["prefix"]."data";
		$table_title   	= array(array("name" => $object["lang"]->translate("#")),
								array("name" => $object["lang"]->translate("string_date")),
							    array("name" => $object["lang"]->translate("string_details")));
								
		////////////////////////////////////////////////////////////////
		// Create Table Object
		////////////////////////////////////////////////////////////////
		$tbl = new x_class_table($object["mysql"], $table_general, "table");
		
		////////////////////////////////////////////////////////////////
		// Delete Item Operations
		////////////////////////////////////////////////////////////////
		$object["var"]->setup($object["extension"]["prefix_variables"]."plane_url", "https://domain/workspace", "");
		if(!defined($object["extension"]["prefix_variables"]."plane_url")) { define($object["extension"]["prefix_variables"]."plane_url", "https://domain/workspace"); }
		$url = hive__hen(constant($object["extension"]["prefix_variables"]."plane_url"));
		if(trim($url ?? '' ) == "") { $url = hive__hen("https://example/workspace"); } 
		
		////////////////////////////////////////////////////////////////
		// Table Flush Operation
		////////////////////////////////////////////////////////////////
		if(@$_POST["hive_submit_flush_table"] OR @$_GET["op"] == "flush") {
			if(@$_GET["confirm"] != "confirmed") { 
				?>
				<script>
					Swal.fire({
					  title: <?php echo json_encode($object["lang"]->translate("string_flushtable")); ?>,
					  html: "<?php echo $object["lang"]->translate("string_item_flushrly"); ?><form method='post' action='<?php echo "./?"._HIVE_URL_GET_[0]."="._HIVE_URL_CUR_[0]."&"._HIVE_URL_GET_[1]."="._HIVE_URL_CUR_[1]."&confirm=confirmed"; ?>'><input type='hidden' name='hive_submit_flush_table_token' value='<?php echo $object["csrf"]->get(); ?>'><input type='hidden' name='hive_submit_flush_table' value='1'><br /><input type='submit' class=\"btn btn-danger\" value='<?php echo htmlentities($object["lang"]->translate("string_yes") ?? ''); ?>'></form>",
					  showCancelButton: false,
					  showCloseButton: true,
					  showConfirmButton: false,
					  allowOutsideClick: false,
					  willClose: () => {
						window.location.href = '<?php echo hive__url(array(_HIVE_URL_CUR_[0])); ?>';
					  }
					});
				</script>
				<?php 
			} else { 
				if($object["csrf"]->check(@$_POST["hive_submit_flush_table_token"])) { 
					$object["mysql"]->query("DELETE FROM ".$table_general."");
					$object["mysql"]->query("ALTER TABLE ".$table_general." AUTO_INCREMENT = 1;");
					$object["eventbox"]->ok($object["lang"]->translate("event_tableflush"));
				} else { $object["eventbox"]->error($object["lang"]->translate("event_csrf")); }		 
			}
		}			
		
		////////////////////////////////////////////////////////////////
		// Change URL
		////////////////////////////////////////////////////////////////
		if(@$_GET["op"] == "change_url") {
			if(@$_GET["confirm"] != "confirmed") { 
				?>
				<script>
					Swal.fire({
					  title: <?php echo json_encode($object["extension"]["lang"]->translate("change_url")); ?>,
					  html: "<?php echo $object["extension"]["lang"]->translate("change_urltext"); ?><form method='post' action='<?php echo "./?"._HIVE_URL_GET_[0]."="._HIVE_URL_CUR_[0]."&"._HIVE_URL_GET_[1]."="._HIVE_URL_CUR_[1]."&confirm=confirmed&op=change_url"; ?>'><input type='hidden' name='hive_submit_flush_table_token' value='<?php echo $object["csrf"]->get(); ?>'><input type='text' name='hive_submit_flush_cgtext' class='form-control' value='<?php echo $url; ?>'><br /><input type='submit' class=\"btn btn-warning\" value='<?php echo htmlentities($object["lang"]->translate("string_edit") ?? ''); ?>'></form>",
					  showCancelButton: false,
					  showCloseButton: true,
					  showConfirmButton: false,
					  allowOutsideClick: false,
					  willClose: () => {
						window.location.href = '<?php echo hive__url(array(_HIVE_URL_CUR_[0])); ?>';
					  }
					});
				</script>
				<?php 
			} else { 
				if($object["csrf"]->check(@$_POST["hive_submit_flush_table_token"])) { 
					$object["var"]->set($object["extension"]["prefix_variables"]."plane_url", @$_POST["hive_submit_flush_cgtext"], "", true, true);
					$object["eventbox"]->ok($object["extension"]["lang"]->translate("change_done"));
					$object["eventbox"]->skip();
				} else { $object["eventbox"]->error($object["lang"]->translate("event_csrf")); }		 
			}			
		}	
		
		////////////////////////////////////////////////////////////////
		// Delete Item Operations
		////////////////////////////////////////////////////////////////
		$output1 =  $tbl->exec_delete();
		if($output1 == "deleted") { $object["eventbox"]->ok($object["lang"]->translate("event_deleted"));}
		if($output1 == "csrf") { $object["eventbox"]->error($object["lang"]->translate("event_csrf"));}		
		
		////////////////////////////////////////////////////////////////
		// Get Table Values
		////////////////////////////////////////////////////////////////
		$value_array = $object["mysql"]->select("SELECT id, id as newid, creation, request_data FROM ".$table_general." ORDER BY id DESC", true); 
		if(is_array($value_array)) {
			foreach($value_array as $key => $value) {
				if($rq = unserialize($value["request_data"])) { 
					$value_array[$key]["request_data"] = "Event [<b>".@htmlspecialchars(@$rq["event"] ?? '')."</b>]";
					$value_array[$key]["request_data"] .= " Action [<b>".@htmlspecialchars(@$rq["action"] ?? '')."</b>]<br />";
					$value_array[$key]["request_data"] .= "<a target='_blank' rel='noopener' href='".hive__hen($url)."/projects/".hive__hen(@$rq["data"]["project"])."/issues/".hive__hen(@$rq["data"]["id"])."'>".@htmlspecialchars(@$rq["data"]["name"] ?? '')."</a><br />";
					$value_array[$key]["request_data"] .= "<small>Priority [<b>".@htmlspecialchars(@$rq["data"]["priority"] ?? '')."</b>]</small>";
				
				} else { $value_array[$key]["request_data"] = @htmlspecialchars($value_array[$key]["request_data"] ?? ''); }
				$value_array[$key]["creation"] = @adm_date_format($value_array[$key]["creation"]);
			}
		}		
		
		////////////////////////////////////////////////////////////////
		// Display the Operations Bar!
		////////////////////////////////////////////////////////////////
		echo sf__theme_box_start();
			echo "<form method='post' action='./?"._HIVE_URL_GET_[0]."="._HIVE_URL_CUR_[0]."'>";
					echo '<button name="hive_submit_flush_table" type="submit" class="btn btn-danger">'.$object["lang"]->translate("string_flushtable").'</button> ';
					echo '<a href="./?l1='._HIVE_URL_CUR_[0].'&op=change_url" class="btn btn-warning">'.$object["extension"]["lang"]->translate("change_url").'</a> ';
					echo "<input type='hidden' name='hive_submit_flush_table_token' value='".$object["csrf"]->get()."'>";
					echo "<input type='hidden' name='hive_submit_flush_table' value='1'>";
			echo "</form>";
		echo sf__theme_box_end();		

		////////////////////////////////////////////////////////////////////////////////////////////////
		// Space Fix
		////////////////////////////////////////////////////////////////////////////////////////////////		
		echo sf__theme_space_fix();
		
		////////////////////////////////////////////////////////////////
		// Display the Table!
		////////////////////////////////////////////////////////////////
		echo sf__theme_box_start(false);
		$tbl->spawn_table($table_title, $value_array, false, hive__hsc($object["lang"]->translate("string_delete")), false, hive__hsc($object["lang"]->translate("string_delete")), "table table-bordered table-striped table-hover dataTable js-exportable");
		echo sf__theme_box_end();		
		
		////////////////////////////////////////////////////////////////
		// Replace Buttons
		////////////////////////////////////////////////////////////////
		?>
			<script>
				// Get all buttons that start with "x_class_table_exec_del_submit"
				var buttons = document.querySelectorAll('button[name^="x_class_table_exec_del_submit"]');

				// Loop through the NodeList and add the class to each button
				buttons.forEach(button => {
					button.classList.add('btn');
					button.classList.add('btn-danger');
				});			
			</script>
		<?php			

		////////////////////////////////////////////////////////////////////////////////////////////////
		// Space Fix
		////////////////////////////////////////////////////////////////////////////////////////////////		
		echo sf__theme_space_fix();
			
			
	} else { if(!defined("_ADM_ERROR_401_")) { define("_ADM_ERROR_401_", 1); } }  