# Extension: Kiwi - Web Hooks

## General Information

Easily Receive Plane Webhooks and sort Nortifications in a organized manner.

## Suitefish Extension Module
This is a suitfish-cms extension module for the administrator interface. Explore suitefish-cms guides, examples, and best practices to get the most out of Suitefish CMS. Whether you're a developer or an admin, you'll find everything you need to get started here: [https://bugfishtm.github.io/suitefish-cms](https://bugfishtm.github.io/suitefish-cms).

## License Information

See the included License.md file for information about this projects license.

🐟 Bugfish <3