<?php if(isset($this)) { if(!is_object($this)) { Header("Location: ../"); exit(); } } else { Header("Location: ../"); exit(); }
#		 ____  __  __  ___  ____  ____  ___  _   _ 
#		(  _ \(  )(  )/ __)( ___)(_  _)/ __)( )_( )
#		 ) _ < )(__)(( (_-. )__)  _)(_ \__ \ ) _ ( 
#		(____/(______)\___/(__)  (____)(___/(_) (_) www.bugfish.eu
#				 ___ _   _ ___ _____ ___ ___ ___ ___ _  _ 
#				/ __| | | |_ _|_   _| __| __|_ _/ __| || |
#				\__ \ |_| || |  | | | _|| _| | |\__ \ __ |
#				|___/\___/|___| |_| |___|_| |___|___/_||_|
#		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]
#
#		This program is free software: you can redistribute it and/or modify
#		it under the terms of the GNU General Public License as published by
#		the Free Software Foundation, either version 3 of the License, or
#		(at your option) any later version.
#
#		This program is distributed in the hope that it will be useful,
#		but WITHOUT ANY WARRANTY; without even the implied warranty of
#		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#		GNU General Public License for more details.
#
#		You should have received a copy of the GNU General Public License
#		along with this program.  If not, see <https://www.gnu.org/licenses/>. ?>
##########################################################################################
## Extension Related
##########################################################################################

################ mod_site.php - Страница  
site_title=Вебхуки (plane.so)  
site_heading_text=Эта страница служит для управления входящими запросами вебхуков для веб-софта plane.so!  
site_no_permission=У вас нет прав для просмотра этой страницы.  

change_url=Изменить URL  
change_done=URL был изменен!  
change_urltext=Этот URL будет добавлен перед URL задач для перенаправления на правильную страницу plane.so.  

################ mod_permission.php - Разрешения  
permission_name=Доступ  
permission_descr=Разрешение на просмотр страницы содержимого этого расширения и выполнение всех доступных функций.  

################ mod_nav.php - Навигация  
nav_title=Вебхуки (plane.so)  

################ Переводы версии магазина  
store_version_name=Plane.so: Вебхуки  
store_version_description=Легко получайте вебхуки Plane и сортируйте уведомления в организованном виде для https://plane.so.  
