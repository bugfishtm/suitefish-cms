<?php if(isset($this)) { if(!is_object($this)) { Header("Location: ../"); exit(); } } else { Header("Location: ../"); exit(); }
#		 ____  __  __  ___  ____  ____  ___  _   _ 
#		(  _ \(  )(  )/ __)( ___)(_  _)/ __)( )_( )
#		 ) _ < )(__)(( (_-. )__)  _)(_ \__ \ ) _ ( 
#		(____/(______)\___/(__)  (____)(___/(_) (_) www.bugfish.eu
#				 ___ _   _ ___ _____ ___ ___ ___ ___ _  _ 
#				/ __| | | |_ _|_   _| __| __|_ _/ __| || |
#				\__ \ |_| || |  | | | _|| _| | |\__ \ __ |
#				|___/\___/|___| |_| |___|_| |___|___/_||_|
#		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]
#
#		This program is free software: you can redistribute it and/or modify
#		it under the terms of the GNU General Public License as published by
#		the Free Software Foundation, either version 3 of the License, or
#		(at your option) any later version.
#
#		This program is distributed in the hope that it will be useful,
#		but WITHOUT ANY WARRANTY; without even the implied warranty of
#		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#		GNU General Public License for more details.
#
#		You should have received a copy of the GNU General Public License
#		along with this program.  If not, see <https://www.gnu.org/licenses/>. ?>
##########################################################################################
## Extension Related
##########################################################################################

################ mod_site.php - Page
site_title=Web Hooks (plane.so)
site_heading_text=Cette page sert à gérer les requêtes entrantes de webhooks pour le logiciel web plane.so !
site_no_permission=Vous n'avez pas la permission de voir cette page.

change_url=Changer l'URL
change_done=L'URL a été modifiée !
change_urltext=Cette URL sera placée devant les URLs des problèmes pour rediriger vers la page correcte de plane.so.

################ mod_permission.php - Permissions
permission_name=Accès
permission_descr=Permission d'afficher la page de contenu de cette extension et d'exécuter toutes les fonctionnalités disponibles.

################ mod_nav.php - Navigation
nav_title=Web Hooks (plane.so)

################ Traductions de Versionnement de la Boutique
store_version_name=Plane.so : Web Hooks
store_version_description=Recevez facilement les Webhooks de Plane et triez les notifications de manière organisée pour https://plane.so.
