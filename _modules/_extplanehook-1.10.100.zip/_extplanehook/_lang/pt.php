<?php if(isset($this)) { if(!is_object($this)) { Header("Location: ../"); exit(); } } else { Header("Location: ../"); exit(); }
#		 ____  __  __  ___  ____  ____  ___  _   _ 
#		(  _ \(  )(  )/ __)( ___)(_  _)/ __)( )_( )
#		 ) _ < )(__)(( (_-. )__)  _)(_ \__ \ ) _ ( 
#		(____/(______)\___/(__)  (____)(___/(_) (_) www.bugfish.eu
#				 ___ _   _ ___ _____ ___ ___ ___ ___ _  _ 
#				/ __| | | |_ _|_   _| __| __|_ _/ __| || |
#				\__ \ |_| || |  | | | _|| _| | |\__ \ __ |
#				|___/\___/|___| |_| |___|_| |___|___/_||_|
#		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]
#
#		This program is free software: you can redistribute it and/or modify
#		it under the terms of the GNU General Public License as published by
#		the Free Software Foundation, either version 3 of the License, or
#		(at your option) any later version.
#
#		This program is distributed in the hope that it will be useful,
#		but WITHOUT ANY WARRANTY; without even the implied warranty of
#		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#		GNU General Public License for more details.
#
#		You should have received a copy of the GNU General Public License
#		along with this program.  If not, see <https://www.gnu.org/licenses/>. ?>
##########################################################################################
## Extension Related
##########################################################################################

################ mod_site.php - Página  
site_title=Web Hooks (plane.so)  
site_heading_text=Esta página serve para gerenciar solicitações de webhooks recebidas para o software web plane.so!  
site_no_permission=Você não tem permissão para visualizar esta página.  

change_url=Alterar URL  
change_done=O URL foi alterado!  
change_urltext=Este URL será colocado antes dos URLs de problemas para redirecionar para a página correta do plane.so.  

################ mod_permission.php - Permissões  
permission_name=Acesso  
permission_descr=Permissão para visualizar a página de conteúdo desta extensão e executar todas as funcionalidades disponíveis.  

################ mod_nav.php - Navegação  
nav_title=Web Hooks (plane.so)  

################ Traduções da versão da loja  
store_version_name=Plane.so: Web Hooks  
store_version_description=Receba Webhooks do Plane facilmente e organize notificações de forma organizada para https://plane.so.  
