<?php if(isset($this)) { if(!is_object($this)) { Header("Location: ../"); exit(); } } else { Header("Location: ../"); exit(); }
#		 ____  __  __  ___  ____  ____  ___  _   _ 
#		(  _ \(  )(  )/ __)( ___)(_  _)/ __)( )_( )
#		 ) _ < )(__)(( (_-. )__)  _)(_ \__ \ ) _ ( 
#		(____/(______)\___/(__)  (____)(___/(_) (_) www.bugfish.eu
#				 ___ _   _ ___ _____ ___ ___ ___ ___ _  _ 
#				/ __| | | |_ _|_   _| __| __|_ _/ __| || |
#				\__ \ |_| || |  | | | _|| _| | |\__ \ __ |
#				|___/\___/|___| |_| |___|_| |___|___/_||_|
#		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]
#
#		This program is free software: you can redistribute it and/or modify
#		it under the terms of the GNU General Public License as published by
#		the Free Software Foundation, either version 3 of the License, or
#		(at your option) any later version.
#
#		This program is distributed in the hope that it will be useful,
#		but WITHOUT ANY WARRANTY; without even the implied warranty of
#		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#		GNU General Public License for more details.
#
#		You should have received a copy of the GNU General Public License
#		along with this program.  If not, see <https://www.gnu.org/licenses/>. ?>
##########################################################################################
## Extension Related
##########################################################################################

################ mod_site.php - Pagina
site_title=Web Hooks (plane.so)
site_heading_text=Questa pagina serve a gestire le richieste di webhook in arrivo per il software web plane.so!
site_no_permission=Non hai il permesso di visualizzare questa pagina.

change_url=Cambia URL
change_done=L'URL è stato cambiato!
change_urltext=Questo URL verrà aggiunto davanti agli URL dei problemi per reindirizzare alla pagina corretta di plane.so.

################ mod_permission.php - Permessi
permission_name=Accesso
permission_descr=Permesso di visualizzare la pagina dei contenuti di questa estensione e di eseguire tutte le funzionalità disponibili.

################ mod_nav.php - Navigazione
nav_title=Web Hooks (plane.so)

################ Traduzioni di Versionamento dello Store
store_version_name=Plane.so: Web Hooks
store_version_description=Ricevi facilmente i Webhooks di Plane e organizza le notifiche in modo ordinato per https://plane.so.
