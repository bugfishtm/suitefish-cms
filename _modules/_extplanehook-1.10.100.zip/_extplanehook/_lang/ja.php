<?php if(isset($this)) { if(!is_object($this)) { Header("Location: ../"); exit(); } } else { Header("Location: ../"); exit(); }
#		 ____  __  __  ___  ____  ____  ___  _   _ 
#		(  _ \(  )(  )/ __)( ___)(_  _)/ __)( )_( )
#		 ) _ < )(__)(( (_-. )__)  _)(_ \__ \ ) _ ( 
#		(____/(______)\___/(__)  (____)(___/(_) (_) www.bugfish.eu
#				 ___ _   _ ___ _____ ___ ___ ___ ___ _  _ 
#				/ __| | | |_ _|_   _| __| __|_ _/ __| || |
#				\__ \ |_| || |  | | | _|| _| | |\__ \ __ |
#				|___/\___/|___| |_| |___|_| |___|___/_||_|
#		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]
#
#		This program is free software: you can redistribute it and/or modify
#		it under the terms of the GNU General Public License as published by
#		the Free Software Foundation, either version 3 of the License, or
#		(at your option) any later version.
#
#		This program is distributed in the hope that it will be useful,
#		but WITHOUT ANY WARRANTY; without even the implied warranty of
#		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#		GNU General Public License for more details.
#
#		You should have received a copy of the GNU General Public License
#		along with this program.  If not, see <https://www.gnu.org/licenses/>. ?>
##########################################################################################
## Extension Related
##########################################################################################

################ mod_site.php - ページ
site_title=Web Hooks (plane.so)
site_heading_text=このページは、plane.soウェブソフトウェア向けの受信ウェブフックリクエストを管理するためのものです！
site_no_permission=このページを表示する権限がありません。

change_url=URLを変更
change_done=URLが変更されました！
change_urltext=このURLは問題のURLの前に配置され、正しいplane.soページにリダイレクトされます。

################ mod_permission.php - 権限
permission_name=アクセス
permission_descr=この拡張機能のコンテンツページを表示し、利用可能なすべての機能を実行するための権限。

################ mod_nav.php - ナビゲーション
nav_title=Web Hooks (plane.so)

################ ストアバージョニング翻訳
store_version_name=Plane.so: Web Hooks
store_version_description=Plane Webhooksを簡単に受信し、通知を整然と整理してhttps://plane.soで利用できます。
