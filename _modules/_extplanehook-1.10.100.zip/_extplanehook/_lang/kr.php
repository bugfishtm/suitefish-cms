<?php if(isset($this)) { if(!is_object($this)) { Header("Location: ../"); exit(); } } else { Header("Location: ../"); exit(); }
#		 ____  __  __  ___  ____  ____  ___  _   _ 
#		(  _ \(  )(  )/ __)( ___)(_  _)/ __)( )_( )
#		 ) _ < )(__)(( (_-. )__)  _)(_ \__ \ ) _ ( 
#		(____/(______)\___/(__)  (____)(___/(_) (_) www.bugfish.eu
#				 ___ _   _ ___ _____ ___ ___ ___ ___ _  _ 
#				/ __| | | |_ _|_   _| __| __|_ _/ __| || |
#				\__ \ |_| || |  | | | _|| _| | |\__ \ __ |
#				|___/\___/|___| |_| |___|_| |___|___/_||_|
#		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]
#
#		This program is free software: you can redistribute it and/or modify
#		it under the terms of the GNU General Public License as published by
#		the Free Software Foundation, either version 3 of the License, or
#		(at your option) any later version.
#
#		This program is distributed in the hope that it will be useful,
#		but WITHOUT ANY WARRANTY; without even the implied warranty of
#		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#		GNU General Public License for more details.
#
#		You should have received a copy of the GNU General Public License
#		along with this program.  If not, see <https://www.gnu.org/licenses/>. ?>
##########################################################################################
## Extension Related
##########################################################################################

################ mod_site.php - 페이지  
site_title=웹훅 (plane.so)  
site_heading_text=이 페이지는 plane.so 웹소프트웨어를 위한 들어오는 웹훅 요청을 관리하기 위해 제공됩니다!  
site_no_permission=이 페이지를 볼 권한이 없습니다.  

change_url=URL 변경  
change_done=URL이 변경되었습니다!  
change_urltext=이 URL은 이슈 URL 앞에 배치되어 올바른 plane.so 페이지로 리디렉션됩니다.  

################ mod_permission.php - 권한  
permission_name=접근  
permission_descr=이 확장의 콘텐츠 페이지를 보고 사용 가능한 모든 기능을 실행할 수 있는 권한.  

################ mod_nav.php - 탐색  
nav_title=웹훅 (plane.so)  

################ 스토어 버전 번역  
store_version_name=Plane.so: 웹훅  
store_version_description=Plane 웹훅을 쉽게 받고 https://plane.so에 대한 알림을 정리된 방식으로 정렬합니다.  
