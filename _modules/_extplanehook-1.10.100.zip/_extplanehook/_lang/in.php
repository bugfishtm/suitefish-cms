<?php if(isset($this)) { if(!is_object($this)) { Header("Location: ../"); exit(); } } else { Header("Location: ../"); exit(); }
#		 ____  __  __  ___  ____  ____  ___  _   _ 
#		(  _ \(  )(  )/ __)( ___)(_  _)/ __)( )_( )
#		 ) _ < )(__)(( (_-. )__)  _)(_ \__ \ ) _ ( 
#		(____/(______)\___/(__)  (____)(___/(_) (_) www.bugfish.eu
#				 ___ _   _ ___ _____ ___ ___ ___ ___ _  _ 
#				/ __| | | |_ _|_   _| __| __|_ _/ __| || |
#				\__ \ |_| || |  | | | _|| _| | |\__ \ __ |
#				|___/\___/|___| |_| |___|_| |___|___/_||_|
#		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]
#
#		This program is free software: you can redistribute it and/or modify
#		it under the terms of the GNU General Public License as published by
#		the Free Software Foundation, either version 3 of the License, or
#		(at your option) any later version.
#
#		This program is distributed in the hope that it will be useful,
#		but WITHOUT ANY WARRANTY; without even the implied warranty of
#		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#		GNU General Public License for more details.
#
#		You should have received a copy of the GNU General Public License
#		along with this program.  If not, see <https://www.gnu.org/licenses/>. ?>
##########################################################################################
## Extension Related
##########################################################################################

################ mod_site.php - पृष्ठ  
site_title=वेब हुक्स (plane.so)  
site_heading_text=यह पृष्ठ plane.so वेब सॉफ़्टवेयर के लिए आने वाले वेब हुक अनुरोधों को प्रबंधित करने के लिए है!  
site_no_permission=आपके पास इस पृष्ठ को देखने की अनुमति नहीं है।  

change_url=URL बदलें  
change_done=URL बदल दिया गया है!  
change_urltext=यह URL मुद्दे के URL के सामने रखा जाएगा ताकि सही plane.so पृष्ठ पर पुनर्निर्देशित हो सके।  

################ mod_permission.php - अनुमतियां  
permission_name=पहुंच  
permission_descr=इस एक्सटेंशन के सामग्री पृष्ठ को देखने और सभी उपलब्ध कार्यों को निष्पादित करने की अनुमति।  

################ mod_nav.php - नेविगेशन  
nav_title=वेब हुक्स (plane.so)  

################ स्टोर संस्करण अनुवाद  
store_version_name=Plane.so: वेब हुक्स  
store_version_description=आसानी से Plane वेब हुक प्राप्त करें और सूचनाओं को https://plane.so के लिए व्यवस्थित तरीके से सॉर्ट करें।  
