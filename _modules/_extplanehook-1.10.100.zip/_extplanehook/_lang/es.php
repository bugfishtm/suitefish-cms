<?php if(isset($this)) { if(!is_object($this)) { Header("Location: ../"); exit(); } } else { Header("Location: ../"); exit(); }
#		 ____  __  __  ___  ____  ____  ___  _   _ 
#		(  _ \(  )(  )/ __)( ___)(_  _)/ __)( )_( )
#		 ) _ < )(__)(( (_-. )__)  _)(_ \__ \ ) _ ( 
#		(____/(______)\___/(__)  (____)(___/(_) (_) www.bugfish.eu
#				 ___ _   _ ___ _____ ___ ___ ___ ___ _  _ 
#				/ __| | | |_ _|_   _| __| __|_ _/ __| || |
#				\__ \ |_| || |  | | | _|| _| | |\__ \ __ |
#				|___/\___/|___| |_| |___|_| |___|___/_||_|
#		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]
#
#		This program is free software: you can redistribute it and/or modify
#		it under the terms of the GNU General Public License as published by
#		the Free Software Foundation, either version 3 of the License, or
#		(at your option) any later version.
#
#		This program is distributed in the hope that it will be useful,
#		but WITHOUT ANY WARRANTY; without even the implied warranty of
#		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#		GNU General Public License for more details.
#
#		You should have received a copy of the GNU General Public License
#		along with this program.  If not, see <https://www.gnu.org/licenses/>. ?>
##########################################################################################
## Extension Related
##########################################################################################

################ mod_site.php - Página
site_title=Web Hooks (plane.so)
site_heading_text=¡Esta página sirve para gestionar solicitudes entrantes de webhooks para el software web plane.so!
site_no_permission=No tienes permiso para ver esta página.

change_url=Cambiar URL
change_done=¡La URL ha sido cambiada!
change_urltext=Esta URL se colocará delante de las URLs de los problemas para redirigir a la página correcta de plane.so.

################ mod_permission.php - Permisos
permission_name=Acceso
permission_descr=Permiso para ver la página de contenido de esta extensión y ejecutar todas las funcionalidades disponibles.

################ mod_nav.php - Navegación
nav_title=Web Hooks (plane.so)

################ Traducciones de Versionado de la Tienda
store_version_name=Plane.so: Web Hooks
store_version_description=Recibe fácilmente Webhooks de Plane y organiza las notificaciones de manera ordenada para https://plane.so.
