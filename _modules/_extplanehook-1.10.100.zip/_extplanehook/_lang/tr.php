<?php if(isset($this)) { if(!is_object($this)) { Header("Location: ../"); exit(); } } else { Header("Location: ../"); exit(); }
#		 ____  __  __  ___  ____  ____  ___  _   _ 
#		(  _ \(  )(  )/ __)( ___)(_  _)/ __)( )_( )
#		 ) _ < )(__)(( (_-. )__)  _)(_ \__ \ ) _ ( 
#		(____/(______)\___/(__)  (____)(___/(_) (_) www.bugfish.eu
#				 ___ _   _ ___ _____ ___ ___ ___ ___ _  _ 
#				/ __| | | |_ _|_   _| __| __|_ _/ __| || |
#				\__ \ |_| || |  | | | _|| _| | |\__ \ __ |
#				|___/\___/|___| |_| |___|_| |___|___/_||_|
#		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]
#
#		This program is free software: you can redistribute it and/or modify
#		it under the terms of the GNU General Public License as published by
#		the Free Software Foundation, either version 3 of the License, or
#		(at your option) any later version.
#
#		This program is distributed in the hope that it will be useful,
#		but WITHOUT ANY WARRANTY; without even the implied warranty of
#		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#		GNU General Public License for more details.
#
#		You should have received a copy of the GNU General Public License
#		along with this program.  If not, see <https://www.gnu.org/licenses/>. ?>
##########################################################################################
## Extension Related
##########################################################################################

################ mod_site.php - Sayfa  
site_title=Web Hooklar (plane.so)  
site_heading_text=Bu sayfa, plane.so web yazılımı için gelen web hook isteklerini yönetmek amacıyla kullanılmaktadır!  
site_no_permission=Bu sayfayı görüntüleme izniniz yok.  

change_url=URL'yi Değiştir  
change_done=URL değiştirildi!  
change_urltext=Bu URL, doğru plane.so sayfasına yönlendirmek için sorun URL'lerinin önüne eklenecektir.  

################ mod_permission.php - İzinler  
permission_name=Erişim  
permission_descr=Bu eklentinin içerik sayfasını görüntüleme ve tüm kullanılabilir işlevleri yürütme izni.  

################ mod_nav.php - Navigasyon  
nav_title=Web Hooklar (plane.so)  

################ Mağaza Sürüm Çevirileri  
store_version_name=Plane.so: Web Hooklar  
store_version_description=Plane Webhook'larını kolayca alın ve bildirimleri https://plane.so için düzenli bir şekilde sıralayın.  
