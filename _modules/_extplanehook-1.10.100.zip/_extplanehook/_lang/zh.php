<?php if(isset($this)) { if(!is_object($this)) { Header("Location: ../"); exit(); } } else { Header("Location: ../"); exit(); }
#		 ____  __  __  ___  ____  ____  ___  _   _ 
#		(  _ \(  )(  )/ __)( ___)(_  _)/ __)( )_( )
#		 ) _ < )(__)(( (_-. )__)  _)(_ \__ \ ) _ ( 
#		(____/(______)\___/(__)  (____)(___/(_) (_) www.bugfish.eu
#				 ___ _   _ ___ _____ ___ ___ ___ ___ _  _ 
#				/ __| | | |_ _|_   _| __| __|_ _/ __| || |
#				\__ \ |_| || |  | | | _|| _| | |\__ \ __ |
#				|___/\___/|___| |_| |___|_| |___|___/_||_|
#		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]
#
#		This program is free software: you can redistribute it and/or modify
#		it under the terms of the GNU General Public License as published by
#		the Free Software Foundation, either version 3 of the License, or
#		(at your option) any later version.
#
#		This program is distributed in the hope that it will be useful,
#		but WITHOUT ANY WARRANTY; without even the implied warranty of
#		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#		GNU General Public License for more details.
#
#		You should have received a copy of the GNU General Public License
#		along with this program.  If not, see <https://www.gnu.org/licenses/>. ?>
##########################################################################################
## Extension Related
##########################################################################################

################ mod_site.php - 页面  
site_title=网络钩子 (plane.so)  
site_heading_text=此页面用于管理 plane.so 网络软件的传入网络钩子请求！  
site_no_permission=您没有权限查看此页面。  

change_url=更改 URL  
change_done=URL 已更改！  
change_urltext=此 URL 将添加在问题 URL 前，以重定向到正确的 plane.so 页面。  

################ mod_permission.php - 权限  
permission_name=访问  
permission_descr=查看此扩展内容页面并执行所有可用功能的权限。  

################ mod_nav.php - 导航  
nav_title=网络钩子 (plane.so)  

################ 商店版本翻译  
store_version_name=Plane.so: 网络钩子  
store_version_description=轻松接收 Plane 网络钩子，并以有条理的方式整理 https://plane.so 的通知。  
