<?php
	/* 
		 ____  __  __  ___  ____  ____  ___  _   _ 
		(  _ \(  )(  )/ __)( ___)(_  _)/ __)( )_( )
		 ) _ < )(__)(( (_-. )__)  _)(_ \__ \ ) _ ( 
		(____/(______)\___/(__)  (____)(___/(_) (_) www.bugfish.eu
				 ___ _   _ ___ _____ ___ ___ ___ ___ _  _ 
				/ __| | | |_ _|_   _| __| __|_ _/ __| || |
				\__ \ |_| || |  | | | _|| _| | |\__ \ __ |
				|___/\___/|___| |_| |___|_| |___|___/_||_|
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
	*/
	// Response Code 401
	@http_response_code(401);
	// Get current Sitemodule Name for Extension Action
	$file_path = dirname(__FILE__);
	// Break the path into its components
	$path_parts = explode(DIRECTORY_SEPARATOR, $file_path);
	// Get the second last folder name
	$second_last_folder = $path_parts[count($path_parts) -3];	
	define("_HIVE_OVR_PRE_SETTING_MODE_", $second_last_folder);
	// Check if Settings File exists
	if(file_exists(dirname(__FILE__)."/../../../../settings.php")) { 
		// Include Webite Settings File
		require_once(dirname(__FILE__)."/../../../../settings.php"); 
		$rawData = file_get_contents("php://input");
		$bind 				= array();
		if($bind[0]["value"] 	= json_decode($rawData, true)) { 
			if($bind[0]["value"]["event"]) { 
				$bind[0]["value"] 	= serialize($bind[0]["value"]);
				$object["mysql"]->query("INSERT INTO "._HIVE_SITE_PREFIX_."__extplanehook_data(request_data) VALUES(?);", $bind);
			}
		}
	}
	