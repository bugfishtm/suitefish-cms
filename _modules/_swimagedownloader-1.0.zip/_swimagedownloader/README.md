# Bugfish Image Downloader

🧩 General Information

Welcome to Bugfish Image Downloader, a versatile software tool designed for downloading images from websites. This utility enables you to input a URL, upon which it will retrieve and save all images found on the specified website. The downloaded images are organized into folders within the application's directory.

- Easily download images from websites of your choice.
- Configure settings to search for images within subsites of the specified website.
- Choose to download only high-definition images with a width of at least 1000 pixels.
- Note: While Bugfish Image Downloader is compatible with many websites, it may not work on all. Feel free to give it a try for your image downloading needs.

To run Bugfish Image Downloader, you need a Windows operating system with .NET Framework 4.5 installed. The software is designed to run without the need for installation, and it does not write or utilize any registry keys. All folders and files are created in the same location as the executable file.

📜 License Information

See the included License.md file for information about this projects license.

🐟 Bugfish <3