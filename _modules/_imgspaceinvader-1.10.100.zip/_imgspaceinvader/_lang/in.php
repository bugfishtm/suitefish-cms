<?php if(isset($this)) { if(!is_object($this)) { Header("Location: ../"); exit(); } } else { Header("Location: ../"); exit(); }
#		 ____  __  __  ___  ____  ____  ___  _   _ 
#		(  _ \(  )(  )/ __)( ___)(_  _)/ __)( )_( )
#		 ) _ < )(__)(( (_-. )__)  _)(_ \__ \ ) _ ( 
#		(____/(______)\___/(__)  (____)(___/(_) (_) www.bugfish.eu
#				 ___ _   _ ___ _____ ___ ___ ___ ___ _  _ 
#				/ __| | | |_ _|_   _| __| __|_ _/ __| || |
#				\__ \ |_| || |  | | | _|| _| | |\__ \ __ |
#				|___/\___/|___| |_| |___|_| |___|___/_||_|
#		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]
#
#		This program is free software: you can redistribute it and/or modify
#		it under the terms of the GNU General Public License as published by
#		the Free Software Foundation, either version 3 of the License, or
#		(at your option) any later version.
#
#		This program is distributed in the hope that it will be useful,
#		but WITHOUT ANY WARRANTY; without even the implied warranty of
#		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#		GNU General Public License for more details.
#
#		You should have received a copy of the GNU General Public License
#		along with this program.  If not, see <https://www.gnu.org/licenses/>. ?>
store_version_name=ब्राउज़र गेम: स्पेस इन्वेडर
store_version_description=स्पेस इन्वेडर JS एक आधुनिक वेब-आधारित संस्करण है जो क्लासिक आर्केड खेल का है, जहां खिलाड़ी एक अंतरिक्ष यान को नियंत्रित करके गिरते हुए एलियन आक्रमणकारियों से मुकाबला करते हैं। सरल नियंत्रण और जीवंत ग्राफिक्स के साथ, यह खेल रेट्रो गेमिंग की पुरानी यादों को पकड़ते हुए नए और अनुभवी खिलाड़ियों दोनों के लिए एक रोमांचक अनुभव प्रदान करता है।


