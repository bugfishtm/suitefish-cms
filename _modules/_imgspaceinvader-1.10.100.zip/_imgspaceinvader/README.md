# Space-Invaders

🧩 General Information

Space Invaders is a classic arcade game where the player controls a spaceship and shoots down enemy aliens. This simple game is developed using the p5.js library and is open source.

- Use the arrow keys to move the spaceship left and right.
- Press the spacebar to shoot.

📜 License Information

See the included License.md file for information about this projects license.

🐟 Bugfish <3
