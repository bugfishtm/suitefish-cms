# Theme: Volt

## 🧩 **General Information**

Theme Modules serve to enhance of change the Theme of the Administrator Module Interface.

## 📚 **Suitefish Theme Module**
This is a Suitefish Theme Module for the Administrator Interface! Explore suitefish-cms guides, examples, and best practices to get the most out of Suitefish CMS. Whether you're a developer or an admin, you'll find everything you need to get started here: [https://bugfishtm.github.io/suitefish-cms](https://bugfishtm.github.io/suitefish-cms).

## 🗂️ **Folder Structure**

Organize your theme module extensions ZIP file as follows. Replace `RNAME` with your module name. See inside folders readme.md for some more information.

### _images
Preview images for the readme.md file.

```
./RNAME/_images/
├── ... (Content you may add)
├── index.php (Prevent Directory Listing)
├── README.md (Readme file with Folder Informations)
```

### _lang
Language Translations for Multilangual Store Deployment (Only if you want to deploy multi langual descriptions and names for the store on deployment.)

```
./RNAME/_lang/
├── de.php (Translation File for German)
├── en.php (Translation File for English)
├── es.php (Translation File for Spanish)
├── fr.php (Translation File for French)
├── it.php (Translation File for Italian)
├── ja.php (Translation File for Japanese)
├── zh.php (Translation File for Chinese)
├── ... (Other language Files you may add)
├── index.php (Prevent Directory Listing)
├── README.md (Readme file with Folder Informations)
```

### _licenses
Store your external licenses in this folder!

```
./RNAME/_licenses/
├── example.lic (Example License File)
├── .. (Store your other License files here.)
├── index.php (Prevent Directory Listing)
├── README.md (Readme file with Folder Informations)
```

### Files
Files in the extensions root directory.
```
./RNAME/
├── changelog.php (Changelog info)
├── index.php (Prevent Directory Listing)
├── library.php (Loadup of Theming Library)
├── LICENSE.md (Extensions License)
└── preview.jpg (Preview image)
├── README.md (Extensions Readme)
├── version.php (Versioning info)
```

## 📜 **License Information**

See the included License.md file for information about this projects license.

🐟 Bugfish <3
