<?php
	/* 
		 ____  __  __  ___  ____  ____  ___  _   _ 
		(  _ \(  )(  )/ __)( ___)(_  _)/ __)( )_( )
		 ) _ < )(__)(( (_-. )__)  _)(_ \__ \ ) _ ( 
		(____/(______)\___/(__)  (____)(___/(_) (_) www.bugfish.eu
				 ___ _   _ ___ _____ ___ ___ ___ ___ _  _ 
				/ __| | | |_ _|_   _| __| __|_ _/ __| || |
				\__ \ |_| || |  | | | _|| _| | |\__ \ __ |
				|___/\___/|___| |_| |___|_| |___|___/_||_|
		Copyright (C) 2024 Jan Maurice Dahlmanns [Bugfish]

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		(at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <https://www.gnu.org/licenses/>.
		
		File Description:
			This file will hold functionalities of this template theme!
	*/ if(!is_array(@$object)) { @http_response_code(404); Header("Location: ../"); exit(); }

	#############################################################################################################################################
	// Override Theme Files
	#############################################################################################################################################
	function sf___override_file($object, $action) {
		switch($action) {
			// Theme Change
			case "css.theme_changes.php": ?>

/********************************************************************************************/
/* Volt Theme Additions
/********************************************************************************************/
    .x_class_table_box_table {
		max-width: 100%;
		overflow-x: auto;
	}
	
	.dt-button {
		margin-left: 5px;
	}
	
	h2 {
		font-size: 22px;
	}

			<?php return true; break;
			// Change Collapse
			case "js.card_collapse.php": ?>	


/********************************************************************************************/
/* Automatic Card Collapse Addition
/********************************************************************************************/
    document.addEventListener('DOMContentLoaded', function () {
        const cards = document.querySelectorAll('.hive__card_collapse');

        cards.forEach(card => {
            const header = card.querySelector('.card-header');
            const body = card.querySelector('.card-body');
			body.style.display = 'none'; 
            // Check if the icon exists, if not, create and append it
            let icon = header.querySelector('.material-icons');
            if (!icon) {
                icon = document.createElement('span');
                icon.classList.add('material-icons');
                icon.classList.add('xfpe_floatright');
                icon.classList.add('xfpe_cursorpointer');
                icon.classList.add('xfpe_margintopm20px');
                icon.id = 'cardIcon';
                icon.textContent = 'arrow_drop_down';
                header.appendChild(icon);
            }
			
			icon.style.fontSize = '32px'; 
			
            header.addEventListener('click', () => {
                const isHidden = body.style.display === 'none';

                // Toggle body visibility
                body.style.display = isHidden ? 'block' : 'none';

                // Change icon
                icon.textContent = isHidden ? 'arrow_drop_up' : 'arrow_drop_down';
            });
        });
    });

			<?php return true; break;
			// Set to Empty
			case "js.1.theme_init.php": 		return true; break;
			// Set to Default
			case "js.datatable.php": 			return false; break;
			case "js.tinymce.php": 				return false; break;
			case "css.x_class_eventbox.php": 	return false; break;
			case "css.x_cookiebanner.php": 		return false; break;
			case "css.xjs_popup.php": 			return false; break;
			case "js.menu_switch.php": 			return false; break;
		}; return false;
	}
	
	#############################################################################################################################################
	// Start Theme Buildup
	#############################################################################################################################################
	function sf___theme_start($object) { ?><!DOCTYPE html>
		<html lang="en">
		<head> 
			<!--------------------------------------------------------------------------------------------------------------------->
			<!---- Header Loadup -->
			<!--------------------------------------------------------------------------------------------------------------------->
			<!-- Charset -->
			<meta charset="UTF-8" />
			<!-- Initial Scale -->
			<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
			<!-- Initial Meta -->
			<title><?php if(isset($object["ctheme"]["title"])) { if($object["ctheme"]["title"]) { echo hive__hsc($object["ctheme"]["title"]); ?><?php if(_HIVE_TITLE_SPACER_ != false) { echo _HIVE_TITLE_SPACER_; } } } ?><?php if(is_string(_HIVE_TITLE_)) { echo _HIVE_TITLE_; } ?></title>
			<!--------------------------------------------------------------------------------------------------------------------->
			<!---- CSS File Loadup -->
			<!--------------------------------------------------------------------------------------------------------------------->
			<!-- Materialize Font Loader Css -->
			<link href="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/_theme/adminbsb/css_materialize.css" rel="stylesheet">
			<!-- Materialize Core Css -->
			<link href="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/_theme/adminbsb/css_materialize_main.css" rel="stylesheet">
			<!-- Waves Effect Css -->
			<link href="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/node-waves/waves.css" rel="stylesheet" />
			<!-- Animation Css -->
			<link href="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/animate-css/animate.css" rel="stylesheet" />
			<!-- Morris Css-->
			<link href="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/morrisjs/morris.css" rel="stylesheet" />
			<!-- Select2 Css-->
			<link href="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/select2/select2.min.css" rel="stylesheet" />
			<!-- Datatables Css-->
			<link rel="stylesheet" href="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/datatables/jq.datatables.css">
			<link rel="stylesheet" href="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/datatables/skin/bootstrap/css/dataTables.bootstrap.css">
			<!-- SweetAlert Css-->
			<link rel="stylesheet" href="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/sweetalert2/sweetalert2.min.css">
			<link rel="stylesheet" href="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/notyf/notyf.min.css">
			<link rel="stylesheet" href="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/boxicons/boxicons.css">
			<link rel="stylesheet" href="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/volt/volt.css">
			<!--------------------------------------------------------------------------------------------------------------------->
			<!---- JS File Loadup -->
			<!--------------------------------------------------------------------------------------------------------------------->			
			<!-- Jquery Core Js -->
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/jquery/jquery.min.js"></script>
			<!-- Slimscroll Plugin Js -->
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/jquery-slimscroll/jquery.slimscroll.js"></script>
			<!-- Waves Effect Plugin Js -->
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/node-waves/waves.js"></script>
			<!-- Jquery CountTo Plugin Js -->
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/jquery-countto/jquery.countTo.js"></script>
			<!-- Raphael Plugin Js -->
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/raphael/raphael.min.js"></script>
			<!-- Morris Plugin Js -->
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/morrisjs/morris.js"></script>
			<!-- Theme Related -->
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/@popperjs/core/dist/umd/popper.min.js"></script>	
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/bootstrap5/dist/js/bootstrap.min.js"></script>	
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/onscreen/dist/on-screen.umd.min.js"></script>		
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/nouislider/dist/nouislider.min.js"></script>	
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/smooth-scroll/dist/smooth-scroll.polyfills.min.js"></script>	
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/simplebar/dist/simplebar.min.js"></script>	
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/notyf/notyf.min.js"></script>	
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/momentjs/moment.min.js"></script>	
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/githubbuttons/buttons.js"></script>	
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/chartist/dist/chartist.min.js"></script>	
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>	
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/vanillajs-datepicker/dist/js/datepicker.min.js"></script>	
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/smooth-scroll/dist/smooth-scroll.polyfills.min.js"></script>	
			<!-- ChartJs -->
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/chartjs/Chart.bundle.js"></script>
			<!-- Resumable JS -->
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/resumable/resumable.js"></script>	
			<!-- Datatables JS -->
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/datatables/jq.datatables.js"></script>	
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/datatables/skin/bootstrap/js/dataTables.bootstrap.js"></script>	
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/datatables/extensions/export/dataTables.buttons.min.js"></script>	
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/datatables/extensions/export/buttons.flash.min.js"></script>	
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/datatables/extensions/export/jszip.min.js"></script>	
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/datatables/extensions/export/pdfmake.min.js"></script>	
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/datatables/extensions/export/vfs_fonts.js"></script>	
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/datatables/extensions/export/buttons.html5.min.js"></script>	
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/datatables/extensions/export/buttons.print.min.js"></script>	
			<!-- TinyMCE JS -->
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/tinymce/tinymce.min.js"></script>	
			<!-- Select2 JS -->
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/select2/select2.min.js"></script>	
			<!-- Sweetalert JS -->
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/sweetalert2/sweetalert2.all.min.js"></script>		
			<!-- Sortable JS -->
			<script src="<?php echo _HIVE_URL_REL_; ?>_site/<?php echo _HIVE_MODE_; ?>/_theme/sortable/Sortable.js"></script>
			<!-- Volt CSS -->		
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/_vendor/volt/volt.js"></script>				
			<!--------------------------------------------------------------------------------------------------------------------->
			<!---- Style Additions -->
			<!--------------------------------------------------------------------------------------------------------------------->	
			<style>
				html  {
					max-width: 100% !important;
					overflow-x: hidden !important;
				}
			</style>
			<!--------------------------------------------------------------------------------------------------------------------->
			<!---- Include Websites Meta Extensions -->
			<!--------------------------------------------------------------------------------------------------------------------->		
			<?php  if(isset($object["ctheme"]["add_head_ext"])) { if(@$object["ctheme"]["add_head_ext"]) { echo $object["ctheme"]["add_head_ext"]; } } ?>
			<!--------------------------------------------------------------------------------------------------------------------->
			<!---- Include Websites Favicon -->
			<!--------------------------------------------------------------------------------------------------------------------->		
			<?php  if(isset($object["ctheme"]["add_head_fav"])) { if(@$object["ctheme"]["add_head_fav"]) { echo $object["ctheme"]["add_head_fav"]; } } ?>
			<!--------------------------------------------------------------------------------------------------------------------->
			<!---- CMS File Loadup -->
			<!--------------------------------------------------------------------------------------------------------------------->					
			<!-- Framework Javascript Loader -->
			<script src="<?php echo _HIVE_URL_REL_; ?>_core/javascript.php"></script>
			<!-- Framework Stylesheet Loader -->
			<link href="<?php echo _HIVE_URL_REL_; ?>_core/stylesheet.php"  rel="stylesheet">
		</head>		
		  <body class="">

		<!--------------------------------------------------------------------------------------------------------------------->
		<!---- Navigation Menue -->
		<!--------------------------------------------------------------------------------------------------------------------->	
		<nav class="navbar navbar-dark navbar-theme-primary px-4 col-12 d-lg-none">
			<div class="d-flex align-items-center">
				<button class="navbar-toggler d-lg-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
				  <span class="navbar-toggler-icon"></span>
				</button>
			</div>
		</nav>	
		<nav id="sidebarMenu" class="sidebar d-lg-block bg-gray-800 text-white collapse" data-simplebar>
		
		
		<div class="user-card d-flex d-md-none align-items-center justify-content-between justify-content-md-center pb-4 xfpe_marginright20px xfpe_margintop20px"><div class="d-flex align-items-center"></div><div class="collapse-close d-md-none"><a href="#sidebarMenu" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="true" aria-label="Toggle navigation" class=""><svg class="icon icon-xs" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg></a></div></div>
		
		  <div class="sidebar-inner px-4 pt-3">
			<ul class="nav flex-column pt-3 pt-md-0">
			  <li class="nav-item">
				  <span class="sidebar-icon"></span>
				  <!--<span class="mt-1 ms-1 sidebar-text"></span>-->
			  </li>
				<?php foreach($object["nav"] as $key => $value) { ?>
					<?php if(is_array(@$value["nav_sub"])) {  ?>
					  <li class="nav-item <?php if(_HIVE_URL_CUR_[0] == $value["nav_act"]) { echo "active";} ?>">
						<span
						  class="nav-link  <?php if(_HIVE_URL_CUR_[0] != $value["nav_act"]) { echo "collapsed";} ?>  d-flex justify-content-between align-items-center"
						  data-bs-toggle="collapse" data-bs-target="#submenu-<?php echo $value["nav_act"]; ?>">
						  <span>
							<span class="sidebar-icon">
							  <i class="material-icons"><?php echo $value["nav_img"]; ?></i>
							</span> 
							<span class="sidebar-text"><?php echo $value["nav_title"]; ?></span>
						  </span>
						  <span class="link-arrow">
							<svg class="icon icon-sm" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path></svg>
						  </span>
						</span>
						<div class="multi-level collapse <?php if(_HIVE_URL_CUR_[0] == $value["nav_act"]) { echo "show";} ?>"
						  role="list" id="submenu-<?php echo $value["nav_act"]; ?>" aria-expanded="true">
						  <ul class="flex-column nav">
							  <?php foreach($value["nav_sub"] as $key => $valuex) { ?>
								<li class="nav-item <?php if(_HIVE_URL_CUR_[1] == $valuex["nav_act"] AND _HIVE_URL_CUR_[0] == $value["nav_act"]) { echo "active";} ?>">
								  <a class="nav-link" href="<?php echo $valuex["nav_loc"]; ?>" >
									<span class="sidebar-text"><?php echo $valuex["nav_title"]; ?></span>
								  </a>
								</li>
							  <?php } ?>
						  </ul>
						</div>
					  </li>						
					<?php } elseif(@$value["nav_header"]) { ?>
						<li class="header">
							<?php echo $value["nav_title"]; ?>
						</li>	
					<?php } else {  ?>
					  <li class="nav-item  <?php if(_HIVE_URL_CUR_[0] == $value["nav_act"]) { echo "active";} ?> ">
						<a href="<?php echo $value["nav_loc"]; ?>" class="nav-link" <?php if(@$value["nav_target"]) { echo " target='".$value["nav_target"]."' "; } ?>>
						  <span class="sidebar-icon">
							<i class="material-icons"><?php echo $value["nav_img"]; ?></i>
						  </span> 
						  <span class="sidebar-text"><?php echo $value["nav_title"]; ?></span>
						</a>
					  </li>		
					<?php }  ?>
				<?php }  ?>	
			</ul>
		  </div>
		</nav>
		  
			<!--------------------------------------------------------------------------------------------------------------------->
			<!----Topbar Setup -->
			<!--------------------------------------------------------------------------------------------------------------------->	
			<?php 
				$userimg_profile = "/_site/"._HIVE_MODE_."/_theme/profile.png";
				if(isset($object["ctheme"]["pfm_image_profile"])) { if(@$object["ctheme"]["pfm_image_profile"]) { $userimg_profile = $object["ctheme"]["pfm_image_profile"]; } }
			?>
			<nav class="navbar navbar-top navbar-expand navbar-dashboard navbar-dark ps-0 pe-2 pb-0">
			  <div class="container-fluid px-0">
				<div class="d-flex justify-content-between w-100" id="navbarSupportedContent">
				  <div class="d-flex align-items-center">
				  </div>
				  <ul class="navbar-nav align-items-center">
					<!--------------------------------------------------------------------------------------------------------------------->
					<!---- Go To Top of Page Arrow -->
					<!--------------------------------------------------------------------------------------------------------------------->
					<?php if(_ADM_TH_TOPARROW_ == 1) {  ?>
						<li class="nav-item">
							<a href="#" onclick="window.scrollTo({top: 0,behavior: 'smooth'});" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="true">
								<!--<i class="material-icons">keyboard_arrow_up</i>-->
								<i class="material-icons">keyboard_arrow_up</i>
							</a>
						</li> 
					<?php }  ?>			
					<!--------------------------------------------------------------------------------------------------------------------->
					<!---- Show Topbar Login Icon if not Logged In -->
					<!--------------------------------------------------------------------------------------------------------------------->
					<?php if(_ADM_TH_TOPLOGIN_ == 1) {  ?>
						<?php if(!$object["user"]->loggedIn) {  ?>
							<li class="nav-item">
								<a href="./_core/_action/user_login.php">
									<i class="material-icons">lock</i>
								</a>
							</li> 
						<?php }  ?>
					<?php }  ?>		
					<!--------------------------------------------------------------------------------------------------------------------->
					<!---- Extension Navigation Injection Items -->
					<!--------------------------------------------------------------------------------------------------------------------->			
					<?php
						$object["hive_mode_config"] = hive__init_site_header($object, _HIVE_MODE_);	  
						foreach ($object["extensions_path"] as $filename) {
							if (file_exists($filename."/_admin/mod_topbar.php")) { 
								$object["extension"] 		= hive__init_extension_header($object, basename($filename));		
								require($filename."/_admin/mod_topbar.php");
							}
						}			
					?>					
					<!--------------------------------------------------------------------------------------------------------------------->
					<!---- Topbar Language Change -->
					<!--------------------------------------------------------------------------------------------------------------------->	
					 <?php if(is_array($object["ctheme"]["languages_array"]) AND _ADM_LANG_TB_ == 1) {  ?>
					<li class="nav-item dropdown ms-lg-3">
					  <a class="nav-link dropdown-toggle pt-1 px-0" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						<div class="media d-flex align-items-center">
						  <img class="avatar rounded-circle hive__volt_image_language" alt="Image placeholder" style="object-fit: cover;" src="<?php echo $object["ctheme"]["languages_array"][0]["current_img"]; ?>">
						  <div class="media-body ms-2 text-dark align-items-center d-none d-lg-block">
						  </div>
						</div>
					  </a>
					  <div class="dropdown-menu dashboard-dropdown dropdown-menu-end mt-2 py-1">
					  <?php foreach($object["ctheme"]["languages_array"] as $key => $value) { ?>	
						<a class="dropdown-item d-flex align-items-center" href="<?php echo './?'._HIVE_URL_GET_[0].'='._HIVE_URL_CUR_[0].'&'._HIVE_URL_GET_[1].'='._HIVE_URL_CUR_[1].'&sf____change_lang='.$value["ident"]; ?>">
						  <img src='<?php echo $value["img"]; ?>' class='xfpe_marginright5px'>
						  <?php echo $value["name"]; ?>
						</a>
					<?php } ?>
					  </div>
					</li>
					<?php } ?>
					<!--------------------------------------------------------------------------------------------------------------------->
					<!---- Topbar Notifications Alerts -->
					<!--------------------------------------------------------------------------------------------------------------------->
					<?php
						$use_image = "notification"; 
						if(is_array(@$object["ctheme"]["notifications"])) { 
							if(count($object["ctheme"]["notifications"]) == 0) { 
								$use_image = "notification_empty";
							}
						} else { $use_image = "notification_empty"; } 
					?>
					 <?php if(is_array(@$object["ctheme"]["notifications"])) {  ?>
					<li class="nav-item dropdown ">
					  <a class="nav-link dropdown-toggle pt-1 px-0" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						<img src='./_data/<?php echo _HIVE_MODE_; ?>/_theme/_thvolt/<?php echo $use_image; ?>.png' class='avatar rounded-circle xfpe_marginleft5px' style="object-fit: cover;">
					  </a>
					  <div class="dropdown-menu dashboard-dropdown dropdown-menu-end mt-2 py-1">
						<div class="list-group list-group-flush rounded-top">
						   <!-- <a href="#" class="text-center text-primary fw-bold border-bottom border-light py-3">Notifications</a> -->
						<?php foreach($object["ctheme"]["notifications"] as $key => $value) { ?>
						  <?php if(trim(@$value["alert_url"] ?? '') == "") { @$value["alert_url"] = '#'; } ?> <a href="<?php echo @$value["alert_url"]; ?>" class="list-group-item list-group-item-action border-bottom ">
							<div class="row align-items-center">
								<div class="col-auto">
								</div>
								<div class="col ps-0 ms-2">
								  <div class="d-flex justify-content-between align-items-center">
									<?php //echo adm_date_format(@$value["creation"]); ?>
								  </div>
								  <p class="font-small mt-1 mb-0"><?php echo @$value["alert_text"]; ?></p>
								</div>
							</div>
						   </a>
						<?php } ?>
						  <a href="./?l1=alert" class="dropdown-item text-center fw-bold rounded-bottom py-3">
							<svg class="icon icon-xxs text-gray-400 me-1" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z"></path><path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"></path></svg>
							<?php echo $object["lang"]->translate("admin_top_t_notify_a"); ?>
						  </a>
						</div>
					  </div>
					</li>
					<?php } ?>	
					<!--------------------------------------------------------------------------------------------------------------------->
					<!---- Topbar Theme Change -->
					<!--------------------------------------------------------------------------------------------------------------------->
					<?php if(@$object["ctheme"]["topbar_theme"] AND count($object["suitefish"]["theme"]["valid"]) > 0 AND _ADM_TH_TB_ == 1) {   ?>
					<li class="nav-item dropdown">
					  <a class="nav-link dropdown-toggle pt-1 px-0" data-unread-notifications="true" href="#" role="button" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false">
						<img src='./_data/<?php echo _HIVE_MODE_; ?>/_theme/_thvolt/style.png' class='avatar rounded-circle xfpe_marginleft5px' style="object-fit: cover;">
					  </a>
					  <div class="dropdown-menu dashboard-dropdown dropdown-menu-end mt-2 py-1">
						<div class="list-group list-group-flush rounded-top ">
						  <a <?php echo 'onclick="window.location.href=\'./?'._HIVE_URL_GET_[0].'='._HIVE_URL_CUR_[0].'&'._HIVE_URL_GET_[1].'='._HIVE_URL_CUR_[1].'&sf____change_theme=adminbsb\';"'; ?> class=" list-group-item list-group-item-action border-bottom ">
							<div class="row align-items-center ">
								<div class="col-auto">
								</div>
								<div class="col ps-0 ms-2">
								  <div class="d-flex justify-content-between align-items-center">
								  </div>
								  <p class="font-small mt-1 mb-0"><?php echo $object["lang"]->translate("string_default"); ?> <?php if("adminbsb" == $object["suitefish"]["theme"]["active"]) { echo "(*)"; } ?></p>
								</div>
							</div>
						  </a>
						<?php foreach($object["suitefish"]["theme"]["valid"] as $key => $value) { ?>
						  <a <?php echo 'onclick="window.location.href=\'./?'._HIVE_URL_GET_[0].'='._HIVE_URL_CUR_[0].'&'._HIVE_URL_GET_[1].'='._HIVE_URL_CUR_[1].'&sf____change_theme='.@$value.'\';"'; ?> class=" list-group-item list-group-item-action border-bottom ">
							<div class="row align-items-center">
								<div class="col-auto">
								  <!-- Avatar
								  <img alt="Image placeholder" src="../../assets/img/team/profile-picture-1.jpg" class="avatar-md rounded"> -->
								</div>
								<div class="col ps-0 ms-2">
								  <div class="d-flex justify-content-between align-items-center">
								  </div>
								  <p class="font-small mt-1 mb-0"><?php echo @$value; ?> <?php if($value == $object["suitefish"]["theme"]["active"]) { echo '(*)'; } ?></p>
								</div>
							</div>
						  </a>
						<?php } ?>
						</div>
					  </div>
					</li>
					<?php } ?>	
					<!--------------------------------------------------------------------------------------------------------------------->
					<!---- Profile Menue -->
					<!--------------------------------------------------------------------------------------------------------------------->
					 <?php if(is_array($object["ctheme"]["pfm"])) {  ?>
					<li class="nav-item dropdown ms-lg-3">
					  <a class="nav-link dropdown-toggle pt-1 px-0" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						<div class="media d-flex align-items-center">
						  <img class="avatar rounded-circle" alt="Image placeholder" src="<?php echo $userimg_profile; ?>">
						  <div class="media-body ms-2 text-dark align-items-center d-none d-lg-block">
							<span class="mb-0 font-small fw-bold text-gray-900"><?php echo ""; ?></span>
						  </div>
						</div>
					  </a>
					  <div class="dropdown-menu dashboard-dropdown dropdown-menu-end mt-2 py-1">
					  <?php foreach($object["ctheme"]["pfm"] as $key => $value) { ?>	
						<a class="dropdown-item d-flex align-items-center" href="<?php echo $value["nav_loc"]; ?>">
						  <i class="material-icons xfpe_marginright5px"><?php echo $value["nav_img"]; ?></i> 
						  <?php echo $value["nav_title"]; ?>
						</a>
					<?php } ?>
					  </div>
					</li>
				   <?php } ?>
				  </ul>
				</div>
			  </div>
			</nav>
			
		<main class="content">
	<?php return true; }
	
	#############################################################################################################################################
	// Ending  Buildup Elements
	#############################################################################################################################################	
	function sf___theme_end($object) { 
		if(trim(_ADM_FOOTER_ ?? '') != "") {
			return '</div><footer id="sf__volt_footer" class="bg-white rounded shadow p-5 mb-3 mt-3 pb-3 pt-3">'._ADM_FOOTER_.'</footer></main></body></html>'; 
		} else {
			return '</div></main></body></html>'; 
		}
	}	
	
	#############################################################################################################################################
	// Column Buildup
	#############################################################################################################################################
	function sf___theme_row_start($classes = "") {		
		return '<div class="row '.$classes.'">';  			
	}		
	function sf___theme_row_end() {
		return '</div>';  			
	}		
	
	#############################################################################################################################################
	// Column Buildup
	#############################################################################################################################################
	function sf___theme_col_start($size, $classes = "") {	
		if(is_numeric($size)) { $size = "col-".$size; }
		return '<div class="'.$size.' '.$classes.'">';  			
	}		
	function sf___theme_col_end() {
		return '</div>';  			
	}		
	
	#############################################################################################################################################
	// Topbar Item Buildup
	#############################################################################################################################################
	function sf___theme_topbar_item($object, $icon, $url, $count) {
		return '<li class="nav-item"><a class="nav-link text-dark text-black" href="'.$url.'"><i class="material-icons text-dark" style="font-size: 30px; padding-right: 0px;margin-right: 0px;">'.$icon.'</i>'.$count.'</a></li>'; 			
	} 
					
					
	#############################################################################################################################################
	// Button Elements
	#############################################################################################################################################
	function sf___theme_button_danger($text , $type = "button", $name = false, $js = false, $classes = false) { 
		if($type == false) { $type = "button"; }
		if($classes == false) { $classes = ""; }
		if($js == false) { $js = ""; } else { $js = ' onClick="'.$js.'" '; }
		if($name == false) { $name = ""; }			
		if($type == "button") { return '<button class="btn btn-danger '.$classes.'" '.$js.' name="'.$name.'" type="'.$type.'">'.$text.'</button>';	 }
		if($type == "submit") { return '<button class="btn btn-danger '.$classes.'" '.$js.' name="'.$name.'" type="'.$type.'">'.$text.'</button>';	 }
		if($type == "a") { return '<a class="btn btn-danger '.$classes.'" '.$js.' href="'.$name.'">'.$text.'</a>';	 }
	}
	function sf___theme_button_success($text , $type = "button", $name = false, $js = false, $classes = false) { 
		if($type == false) { $type = "button"; }
		if($classes == false) { $classes = ""; }
		if($js == false) { $js = ""; } else { $js = ' onClick="'.$js.'" '; }
		if($name == false) { $name = ""; }			
		if($type == "button") { return '<button class="btn btn-success '.$classes.'" '.$js.' name="'.$name.'" type="'.$type.'">'.$text.'</button>';	 }
		if($type == "submit") { return '<button class="btn btn-success '.$classes.'" '.$js.' name="'.$name.'" type="'.$type.'">'.$text.'</button>';	 }
		if($type == "a") { return '<a class="btn btn-success '.$classes.'" '.$js.' href="'.$name.'">'.$text.'</a>';	 }
	}	
	function sf___theme_button_warning($text , $type = "button", $name = false, $js = false, $classes = false) { 
		if($type == false) { $type = "button"; }
		if($classes == false) { $classes = ""; }
		if($js == false) { $js = ""; } else { $js = ' onClick="'.$js.'" '; }
		if($name == false) { $name = ""; }		
		if($type == "button") { return '<button class="btn btn-warning '.$classes.'" '.$js.' name="'.$name.'" type="'.$type.'">'.$text.'</button>';	 }
		if($type == "submit") { return '<button class="btn btn-warning '.$classes.'" '.$js.' name="'.$name.'" type="'.$type.'">'.$text.'</button>';	 }
		if($type == "a") { return '<a class="btn btn-warning '.$classes.'" '.$js.' href="'.$name.'">'.$text.'</a>';	 }
	}	
	function sf___theme_button_info($text , $type = "button", $name = false, $js = false, $classes = false) { 
		if($type == false) { $type = "button"; }
		if($classes == false) { $classes = ""; }
		if($js == false) { $js = ""; } else { $js = ' onClick="'.$js.'" '; }
		if($name == false) { $name = ""; }			
		if($type == "button") { return '<button class="btn btn-info '.$classes.'" '.$js.' name="'.$name.'" type="'.$type.'">'.$text.'</button>';	 }
		if($type == "submit") { return '<button class="btn btn-info '.$classes.'" '.$js.' name="'.$name.'" type="'.$type.'">'.$text.'</button>';	 }
		if($type == "a") { return '<a class="btn btn-info '.$classes.'" '.$js.' href="'.$name.'">'.$text.'</a>';	 }
	}	
	function sf___theme_button_primary($text , $type = "button", $name = false, $js = false, $classes = false) { 
		if($type == false) { $type = "button"; }
		if($classes == false) { $classes = ""; }
		if($js == false) { $js = ""; } else { $js = ' onClick="'.$js.'" '; }
		if($name == false) { $name = ""; }		
		if($type == "button") { return '<button class="btn btn-primary '.$classes.'" '.$js.' name="'.$name.'" type="'.$type.'">'.$text.'</button>';	 }
		if($type == "submit") { return '<button class="btn btn-primary '.$classes.'" '.$js.' name="'.$name.'" type="'.$type.'">'.$text.'</button>';	 }
		if($type == "a") { return '<a class="btn btn-primary '.$classes.'" '.$js.' href="'.$name.'">'.$text.'</a>';	 }
	}	
	function sf___theme_button_secondary($text , $type = "button", $name = false, $js = false, $classes = false) { 
		if($type == false) { $type = "button"; }
		if($classes == false) { $classes = ""; }
		if($js == false) { $js = ""; } else { $js = ' onClick="'.$js.'" '; }
		if($name == false) { $name = ""; }			
		if($type == "button") { return '<button class="btn btn-secondary '.$classes.'" '.$js.' name="'.$name.'" type="'.$type.'">'.$text.'</button>';	 }
		if($type == "submit") { return '<button class="btn btn-secondary '.$classes.'" '.$js.' name="'.$name.'" type="'.$type.'">'.$text.'</button>';	 }
		if($type == "a") { return '<a class="btn btn-secondary '.$classes.'" '.$js.' href="'.$name.'">'.$text.'</a>';	 }
	}

	#############################################################################################################################################
	// Space  Buildup Elements
	#############################################################################################################################################	
	function sf___theme_space_fix() { 
		return '<div class="mb-4"></div>'; 
	}	
	function sf___theme_space_s() { 
		return '<div class="mb-2"></div>'; 
	}	
	function sf___theme_space_m() { 
		return '<div class="mb-4"></div>'; 
	}	

	#############################################################################################################################################
	// Box Elements
	#############################################################################################################################################
	function sf___theme_box_start($header = false, $mainclass = "", $headerclass = "", $bodyclass = "") { 
		if($headerclass == false) { $headerclass = ""; }
		if($bodyclass == false) { $bodyclass = ""; }
		if($mainclass == false) { $mainclass = ""; }	
       $output =  '<div class="card '.$mainclass.'">';
		if($header) { 
			$output .=  '<div class="card-header '.$headerclass.'">'.$header.'</div>';
		} 
		$output .=  '<div class="card-body '.$bodyclass.'">';	
		return $output; 
	}
	function sf___theme_box_end() { 	
		return '</div></div>'; 
	}	
	function sf___theme_box($text, $header = false, $mainclass = "", $headerclass = "", $bodyclass = "") { 
		if($headerclass == false) { $headerclass = ""; }
		if($bodyclass == false) { $bodyclass = ""; }
		if($mainclass == false) { $mainclass = ""; } 	
		$output =  '<div class="card '.$mainclass.'">';
		    if($header) { 
				$output .=  '<div class="card-header '.$headerclass.'">'.$header.'</div>';
			} 
			$output .=  '<div class="card-body '.$bodyclass.'">';	
			$output .=  $text;	
			$output .=  '</div>';	
		$output .=  '</div>';	
		return $output; }	

	#############################################################################################################################################
	// Label Boxes
	#############################################################################################################################################
	function sf___theme_label_danger($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<span class="badge bg-danger '.$classes.'">'.$message.'</span>';	
	}
	function sf___theme_label_success($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<span class="badge bg-success '.$classes.'">'.$message.'</span>';	
	}
	function sf___theme_label_warning($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<span class="badge bg-warning '.$classes.'">'.$message.'</span>';	
	}
	function sf___theme_label_info($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<span class="badge bg-info '.$classes.'">'.$message.'</span>';	
	}	
	function sf___theme_label_primary($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<span class="badge bg-primary '.$classes.'">'.$message.'</span>';	
	}	
	function sf___theme_label_secondary($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<span class="badge bg-secondary '.$classes.'">'.$message.'</span>';	
	}

	#############################################################################################################################################
	// Heading Elements
	#############################################################################################################################################
	function sf___theme_h1($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<h1 class="h1 '.$classes.'">'.$message.'</h1>'; 
	}
	function sf___theme_h2($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<h2 class="h2 '.$classes.'">'.$message.'</h2>'; 
	}
	function sf___theme_h3($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<h3 class="h3 '.$classes.'">'.$message.'</h3>'; 
	}
	function sf___theme_h4($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<h4 class="h4 '.$classes.'">'.$message.'</h4>'; 
	}
	function sf___theme_h5($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<h5 class="h5 '.$classes.'">'.$message.'</h1>'; 
	}

	#############################################################################################################################################
	// Badge Boxes
	#############################################################################################################################################
	function sf___theme_badge_danger($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<span class="badge bg-danger '.$classes.'">'.$message.'</span>';	
	}
	function sf___theme_badge_success($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<span class="badge bg-success '.$classes.'">'.$message.'</span>';	
	}
	function sf___theme_badge_warning($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<span class="badge bg-warning '.$classes.'">'.$message.'</span>';	
	}
	function sf___theme_badge_info($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<span class="badge bg-info '.$classes.'">'.$message.'</span>';	
	}
	function sf___theme_badge_primary($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<span class="badge bg-primary '.$classes.'">'.$message.'</span>';	
	}
	function sf___theme_badge_secondary($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<span class="badge bg-secondary '.$classes.'">'.$message.'</span>';	
	}	

	#############################################################################################################################################
	// Alert Boxes
	#############################################################################################################################################
	function sf___theme_alert_danger($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<div class="alert alert-danger '.$classes.'" role="alert">'.$message.'</div>';	
	}
	function sf___theme_alert_success($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<div class="alert alert-success '.$classes.'" role="alert">'.$message.'</div>';	
	}	
	function sf___theme_alert_warning($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<div class="alert alert-warning '.$classes.'" role="alert">'.$message.'</div>';	
	}	
	function sf___theme_alert_info($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<div class="alert alert-info '.$classes.'" role="alert">'.$message.'</div>';	
	}	
	function sf___theme_alert_primary($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<div class="alert alert-primary '.$classes.'" role="alert">'.$message.'</div>';	
	}	
	function sf___theme_alert_secondary($message, $classes = "") { 
		if(!$classes) { $classes = ""; }
		return '<div class="alert alert-secondary '.$classes.'" role="alert">'.$message.'</div>';	
	}

	#############################################################################################################################################
	// Modal Elements
	#############################################################################################################################################
	function sf___theme_modal($text, $title = false, $icon = "info", $closebutton = "true") { 		
		if(!$closebutton) { $closebutton = "false"; }
		if($closebutton) { $closebutton = "true"; }
		$output = "<script>";
			$output .= "$( document ).ready(function() {";
				$output .= "Swal.fire({";
					if($title) {
						$output .= " title: `".str_replace("`", "\\`", $title)."`,";	
					}
					if($icon) {
						$output .= " icon: `".str_replace("`", "\\`", $icon)."`,";
					}
					$output .= " html: `".str_replace("`", "\\`", $text)."`,";
					$output .= "showCloseButton: ".$closebutton;
				$output .= "});";
			$output .= "});";
		$output .= "</script>";
		return $output;
	}			